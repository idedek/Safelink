<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Dashboard");

if($userlog==1){

$urlto = $domainUrl;
if($custom_domain !== "") {
  $urlto = $custom_domain;
}
$uid=dump_udata("id");

if(dump_udata("status")=='INACTIVE'){
echo '
<div class="content">
<center><font color="red"><b>Account Inactive !</b></font><br/><br/>Your account is inactive. Please check <u>INBOX</u> or <u>SPAM</u> folder on your email account, and click on the activation link sent to your email to activate your account!</center></div>';
exit;
}


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Dashboard
	</div>
	<div class="width">
			<div style="text-align: center; padding-bottom: 5px;padding-top: 5px;">
				<h3 style="color: #404142;">Penghasilan: Rp '.number_format(dump_udata('pubalance')).',-</h3>
			</div>
	</div>
	<div class="content">
	<p><b>Shortlink (Rp '.$showRate.',- Per visit):</b></p>';
 
 if(isset($_POST["url"])){

    $url=formpost("url");
    $url=str_replace('http://',null,$url);
    $url=str_replace('https://',null,$url);
    $short = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 5);



    $errors=array();

    if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$url)){
       $errors[]='Site url is not valid!';
     }



    if(empty($errors)){
       $url='http://'.$url.'';
       $add=mysql_query("INSERT INTO urls (userid, url_link, url_short, status, url_ip) VALUES ('$uid','$url','$short','<font color=\'green\'>Active</font>','".$_SERVER['REMOTE_ADDR']."')");
       if($add){
        echo '<div style="padding-bottom: 12px;">
							<span style="color: #348b00;">
								 Link berhasil dipendekan!
							</span>
						</div>
                                               
							Short URL:<br/>
							<input onclick="this.select();" type="text" value="http://'.$urlto.'/'.$short.'" />
                                                <div style="margin-top: 15px;">
<font color="blue">Silahkan share link yg telah anda pendekan di youtube, facebook, twitter, grup whatsapp atau blog untuk mendapatkan uang!</font></div>
<div style="margin-top: 15px;">
						<div style="padding-bottom: 8px; font-weight: bold;">
								 Tambah Short URL:
							</div></div>
';
       }
       else {
         echo '<div style="padding-bottom: 12px;">
							<span style="color:red;">
								Format URL Error!
							</span>
						</div>';
       }
    }
    else {
     dump_error($errors);
    }
   }
echo '
	<form action="" method="POST">
<input type="text" name="url" placeholder="URL" /> <input class="button" type="submit" value="Shorten" />
</form>
</div>
	<div style="padding-top: 10px; padding-bottom: 40px;">
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/link-16.png" /> <a href="/user/shortlink">Short Link</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/space-rocket-16.png" /> <a href="/user/stats">Statistik</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/user-group-16.png" /> <a href="/user/referral">Referral</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/678131-money-16.png" /> <a href="/payout/">Request Pembayaran</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/icon-57-16.png" /> <a href="/user/invoices">Riwayat Pembayaran</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/person_5-16.png" /> <a href="/user/myaccount">Profile Saya</a>
		</div>
    </div>
';



//enf
}
else {
header('Location:/');
}

include 'foot.php';

?>

