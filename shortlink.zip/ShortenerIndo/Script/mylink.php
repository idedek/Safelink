<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - My Links");

if($userlog==1){
$uid=dump_udata("id");

if($custom_domain !== "") {
  $urlto = $custom_domain;
}
if(dump_udata("status")=='INACTIVE'){
echo '

<center><font color="red"><b>Account Inactive !</b></font><br/><br/>Your account is inactive. Please check <u>INBOX</u> or <u>SPAM</u> folder on your email account, and click on the activation link sent to your email to activate your account!</center>';
echo '</div>';
exit;
}


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Buat Short Link
	</div>
	<div class="content">
<p><img style="vertical-align: middle; margin-right: 4px;" src="/theme/images/add.png" /> <a href="/user/shortlink">Buat Short Link!</a></p>';

$page = formget("page");
if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);

$urls=mysql_query("SELECT * FROM urls WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");
if(mysql_num_rows($urls)>0){
 while($show=mysql_fetch_array($urls)){
  echo '
<p><img style="vertical-align: middle; margin-right: 4px;" src="/theme/images/globe.png" width="16" height="16" /> <a href="http://'.$urlto.'/'.$show["url_short"].'">http://'.$urlto.'/'.$show["url_short"].'</a> (<a href="/detail/'.$show["url_short"].'">Detail</a> | <a href="/delete/'.$show["id"].'/'.$show["url_short"].'">Hapus</a>)</p>';

 }
 }
 else {
  echo '<font color="red">You have not added any Link !</font><div style="padding-bottom: 7px;"></div>';
  }
echo '<div style="padding-bottom: 7px;"><center><a href="?id='.$uid.'&page='.($page-1).'">&laquo; Prev</a> | <a href="?id='.$uid.'&page='.($page+1).'">Next &raquo;</a></center></div>';
 echo '</div>';
 
 include 'foot.php';

}

else {

header('Location:/');

}

?>
