<?php
include 'db.php';
include 'functions.php';
 if($userlog==1){
   header('Location:/user/dashboard');
   }
  else{
       if(isset($_POST['firstname']) AND isset($_POST['lastname']) AND isset($_POST['email']) AND isset($_POST['password1']) AND isset($_POST['password2'])){


$firstname=formpost("firstname");
$lastname=formpost("lastname");
$email=formpost("email");
$password1=formpost("password1");
$password2=formpost("password2");

//Codes
$errors=array();
unset($errors);

//Empty
if(strlen($firstname)<1){
$errors[]='First name field left empty!';
}

if(strlen($lastname)<1){
$errors[]='Last name field left empty!';
}

if(strlen($email)<1){
$errors[]='Email field left empty!';
}

if(strlen($password1)<1){
$errors[]='Password field left empty!';
}


if(strlen($password2)<1){
$errors[]='Verify password field left empty!';
}


if(!preg_match('/^([a-zA-Z0-9_.-]+)\@([a-zA-Z0-9_.-]+)\.([a-zA-Z0-9_.-]+)$/', $email)){
$errors[]='Email is not valid!';
}

if($password1!=$password2){
$errors[]='Passwords didn\'t match!';
}

$emch=mysql_query("SELECT * FROM userdata WHERE email='$email'");

if(mysql_num_rows($emch)>0){
$errors[]='Email already registered with another account!';
}

if(empty($errors)){
  $password=md5($password1);
  $doreg=mysql_query("INSERT INTO userdata (email,password,firstname,lastname,status,pubalance,captcha) VALUES ('$email','$password','$firstname','$lastname','ACTIVE','0','1')");

  if($doreg){
$user_data=mysql_query("SELECT * FROM userdata WHERE email='$email'");
$userdat=mysql_fetch_array($user_data);
$userid=$userdat['id'];

  $token=md5(microtime());
  $dover=mysql_query("INSERT INTO verification (userid,token) VALUES ('$userid','$token')");



    $to      = $email;
    $subject = 'Register';
    $message = 'Dear '.$userdat["firstname"].',

Welcome to Paid Short URLs!


Now you can add your Link to shorten and start earning revenue!



Support:
admin@'.$urlsite.'

Thanks
You';
    $headers = 'From: No-Reply<no-reply@'.$urlsite.'>' . "\r\n" .
    'Reply-To: no-reply@'.$urlsite.'' . "\r\n" .
    'X-Mailer: NoReply';

    mail($to, $subject, $message, $headers);
$_SESSION['short_email']=$email;
$_SESSION['short_password']=$password;

header('Location:/user/dashboard');
}
else {
$derror = 'unknown error!';
}
}
else {


foreach($errors as $error){
$derror .= '- '.$error.'<br/>';
}
}
    

//END

}
headtag("$SiteName - Registration");
echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Pendaftaran</div>
		<div class="content">';
if($derror) {
echo '<div style="padding-bottom: 12px; color: #c90000;">
'.$derror.'
</div>';
}
echo '

<form method="post">
First name:<font color="red">*</font><br/>
<input type="text" name="firstname"/><br/>
Last name:<font color="red">*</font><br/>
<input type="text" name="lastname"/><br/>
Email:<font color="red">*</font><br/>
<input type="text" name="email"/><br/>
Password:<font color="red">*</font><br/>
<input type="password" name="password1"/><br/>
Konfirmasi Password:<font color="red">*</font><br/>
<input type="password" name="password2"/><br/>

<input class="button" type="submit" value="Daftar" />
</form>
</div>';


}

include 'foot.php';

?>