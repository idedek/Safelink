<?php

include 'db.php';
include 'functions.php';

if($userlog==1){
header('Location:/user/dashboard');
}
else {
headtag("$SiteName - Forgot password");

echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Lupa Password</div>
		<div class="content">';
  if(isset($_POST['user_email'])){
     
     $user_email=formpost("user_email");

     $errors=array();


     $check_email=mysql_query("SELECT * FROM userdata WHERE email='$user_email'");
     if(mysql_num_rows($check_email)<1){
        $errors[]='No such user with this email!';
      }
     if(strlen($user_email)<1){
        $errors[]='Email field left empty!';
      }



     if(empty($errors)){
        $token=md5(microtime()*2);
        $check_if=mysql_query("SELECT * FROM passret WHERE email='$user_email'");
        if(mysql_num_rows($check_if)<1){
        $do_input=mysql_query("INSERT INTO passret (email,token) VALUES ('$token','$user_email')");
         }
        else {
        $do_input=mysql_query("UPDATE passret SET token='$token' WHERE email='$email'");
         }

        if($do_input){
           
           
        
   
    $to      = $user_email;
    $subject = $SiteName.' Password Reset';
    $message = 'Dear user,

Please click bellow link to rest your password and choose a new one!

http://'.$domainUrl.'/reset/'.$user_email.'/'.$token.'



Support:
support@'.$domainUrl.'

Thanks,
'.$SiteName.' Team,
'.$domainUrl;
    $headers = 'From: 9ad.me<no-reply@'.$domainUrl.'>' . "\r\n" .
    'Reply-To: no-reply@'.$domainUrl. "\r\n" .
    'X-Mailer: 9ad';

    mail($to, $subject, $message, $headers);
echo '&raquo; <font color="green">Your Password reset link has successfully sent to your email, please check your email Inbox or Spam folder!</font><br/><br/>';


}
}
else {
echo '<font color="red"> Error happened!</font>';
foreach($errors as $error){
echo '<font color="red">'.$error.'</font><br/>';
}

}


}
echo '<p>Please enter your email address below to change your password.</p>
<div class="registration-login">
<form method="post"><p>Your Email Address:<br/><input type="text" name="user_email"/></p>
<p><input class="button" type="submit" value="Send"/></p>
</form>
</div>';

}

echo '</div>';


include 'foot.php';

?>