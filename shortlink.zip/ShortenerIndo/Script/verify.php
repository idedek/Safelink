<?php

include 'db.php';
include 'functions.php';

headtag("Verify - $SiteName");
$id=formget("id");
$token=formget("token");

$vch=mysql_query("SELECT * FROM userdata WHERE id='$id'");

if(mysql_num_rows($vch)<1){

echo '<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/flat/images/login.png); margin-right: 2px;" class="icon"></div>
													Login
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/flat/images/register.png); margin-right: 2px;" class="icon"></div>
													Registration
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="http://fb.com/9ad.me">
													<div style="background-image: url(/flat/images/fbwhite.png); margin-right: 2px;" class="icon"></div>
													Facebook
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
<div class="content"><center><font color="red">User Not Found</font></div>
';
include 'foot.php';
exit;
}

$gvch=mysql_fetch_array($vch);

if($gvch['status']=='ACTIVE'){

echo '<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/flat/images/login.png); margin-right: 2px;" class="icon"></div>
													Login
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/flat/images/register.png); margin-right: 2px;" class="icon"></div>
													Registration
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="http://fb.com/9ad.me">
													<div style="background-image: url(/flat/images/fbwhite.png); margin-right: 2px;" class="icon"></div>
													Facebook
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
<div class="content"><center><font color="red">This Account Already Actived !</font></div>
';

}

else {

$doit=mysql_query("UPDATE userdata SET status='ACTIVE' WHERE id='$id'");

if($doit){
echo '<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/flat/images/login.png); margin-right: 2px;" class="icon"></div>
													Login
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/flat/images/register.png); margin-right: 2px;" class="icon"></div>
													Registration
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="http://fb.com/9ad.me">
													<div style="background-image: url(/flat/images/fbwhite.png); margin-right: 2px;" class="icon"></div>
													Facebook
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
<div class="content"><center><font color="green">Your Account Successfully Verified ! Now you can <a href="/user/login">Login</a> and start short your link to get more Earning !</font></div>';
}
}

include 'foot.php';

?>

