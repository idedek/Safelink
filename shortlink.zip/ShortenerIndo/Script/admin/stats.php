<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Stats");

if($adminlog==1){
$imp=mysql_query("SELECT * FROM imp");
$imps=0;

while($show=mysql_fetch_array($imp)){
$imps=($imps+$show['imp']);
}
$total_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks"));
$total_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE status='VALID'"));
$date=date("d-m-Y");
$today_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date'"));
$today_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date' AND status='VALID'"));


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Statistics
	</div>
	<div class="content">';
echo '<div style="padding-top: 10px; padding-bottom: 20px;">
<p>
<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/invalid.png" />
	Visit Hari Ini: <font color="red"><b>'.$today_clicks.'</b></font>		
</p>
<p>
<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/invalid.png" />
	Total Visit: <font color="red"><b>'.$total_clicks.'</b></font>		
</p>
<p>
<img style="vertical-align: middle; margin-right: 10px;" src="/theme/img/valid.png" />
	Visit Valid Hari Ini: <font color="green"><b>'.$today_vclicks.'</b></font>		
</p>
<p>
<img style="vertical-align: middle; margin-right: 10px;" src="/theme/img/valid.png" />
	Total Visit Valid: <font color="green"><b>'.$total_vclicks.'</b></font>		
</p>
</div>';

echo '<b>&raquo; Statistic Report</b><div class="alinea"></div>
<div style="overflow: scroll;">';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*50;
$end=(50);

$stat=mysql_query("SELECT * FROM clicks ORDER BY id DESC LIMIT $start,$end");

if(mysql_num_rows($stat)>0){

echo '<table width="100%">
<tbody>
<tr>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>User</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>Tgl</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>IP</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>User-Agent</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>Referer</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>Link</b></th>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>Status</b></th>
</tr>';

while($show=mysql_fetch_array($stat)){
$sourceUrl=parse_url($show["host"]);
$host=$sourceUrl['host'];
echo '<tr>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$show["userid"].'</td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$show["time"].'</td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$show["ip"].'</td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.strstr(urldecode($show["ua"]),'(',true).'</td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$host.'</td>
<td style="text-align: center; padding: 20px;" colspan="0%"><a href="/'.$show["urlid"].'">'.$_SERVER["HTTP_HOST"].'/'.$show["urlid"].'</a></td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$show["status"].'</td>
</tr>';


}

echo '
</tbody>
</table>
</div>
';

echo '<center><a href="?page='.($page-1).'">Prev</a> - <a href="?page='.($page+1).'">Next</a></center>';
}
else {
echo '<center>There is no clicks!</center>';
}

echo '</div>';
include '../foot.php';
}
else{
header('Location:index.php');
}
?>
