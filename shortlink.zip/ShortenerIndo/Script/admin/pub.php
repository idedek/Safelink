<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Edit Publisher Balance");

if($adminlog==1){

 $uid=formget("id");

 $userd=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));
 $balance=$userd["pubalance"];

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Editor Publisher
	</div>
	<div class="content">';
 if(isset($_POST["bal"])){
   
   $newbal=formpost("bal");

   $doit=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
   if($doit){
     echo '<center>New Balance has edited!</center><br/>';
   }
   else {
     echo '<center">Unknown Error!</center><br/>';
   }
   }
  echo '<div class="registration-login"><form method="post"><p>New Balance:<br/><input type="text" name="bal" value="'.$balance.'"/></p><p><input class="button" type="submit" value="Edit"/></p></form>';
   
 echo '</div>
</div>';
 include '../foot.php';
 }
 else {
  header('Location:login.php');
 }
 ?>