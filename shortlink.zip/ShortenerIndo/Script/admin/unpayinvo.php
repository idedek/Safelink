<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Pay User
	</div>
	<div class="content">';
$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);

$invoice=mysql_query("SELECT * FROM invoice WHERE status='PENDING' ORDER BY id DESC LIMIT $start,$end");


while($invoices=mysql_fetch_array($invoice)){
echo '<p>Invoice ID: '.$invoices["id"].'<br/>&bull; Jumlah: <font color="green"><b>Rp '.$invoices["amount"].'</b></font><br/>&bull; Metode: '.$invoices["method"].'<br />&bull; Tujuan: '.$invoices["via"].'<br/>&bull; Tanggal: '.$invoices["time"].'<br/>&bull; User ID: '.$invoices["userid"].'<br/> &bull; [<a href="pay.php?id='.$invoices["id"].'">Bayar Sekarang</a>]</p><hr />';
}

echo '<a href="?page='.($page-1).'">Prev</a> - <a href="?page='.($page+1).'">Next</a></div>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>
