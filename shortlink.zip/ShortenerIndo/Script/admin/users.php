<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Users");

if($adminlog==1){

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Users
	</div>
	<div class="content">';

echo '<div style="padding-top: 15px; padding-bottom: 15px; padding-left: 10px;">&bull; Sort By: <a href="?sort=latest">Latest</a> - <a href="?sort=money">Balance</a> - <a href="?sort=name">Name</a></div>';

$sort=formget("sort");
$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);
if($sort=="money"){
$stat=mysql_query("SELECT * FROM userdata ORDER BY pubalance DESC LIMIT $start,$end");
}
elseif($sort=="name"){
$stat=mysql_query("SELECT * FROM userdata ORDER BY firstname ASC LIMIT $start,$end");
}
else {
$stat=mysql_query("SELECT * FROM userdata ORDER BY id DESC LIMIT $start,$end");
}
if(mysql_num_rows($stat)>0){

while($show=mysql_fetch_array($stat)){

echo '<p>
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/account.png" /> <a href="user.php?id='.$show["id"].'">'.ucfirst($show["firstname"]).' '.ucfirst($show["lastname"]).'</a> ID = '.$show["id"].'
</p>';

}
echo '<div class="cabinet_item" align="center"><a href="?page='.($page-1).'">Prev</a> - <a href="?page='.($page+1).'">Next</a></div>';
}

echo '</div>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
