<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - User Details");

if($adminlog==1){

 $uid=formget("id");
 $notifcpt = "";
 $notifsts = "";
 if($_GET['captcha']) {
   $capth = $_GET['captcha'];
    if($capth == 1) {
      $captcha= 1;
    }
    if($capth == 2) {
      $captcha= 0;
    }
   $upcpt=mysql_query("UPDATE userdata SET captcha='$captcha' WHERE id='$uid'");
   $notifcpt = '<font color="ref">Error update!</font>';
   if($upcpt) {
     $notifcpt= '<font color="green">Success update!</font>';
  }
 }
 if(isset($_GET['cstatus'])) {
    $sts = $_GET['cstatus'];
    if($sts == 1) {
      $status = "ACTIVE";
    }
    if($sts == 2) {
      $status = "INACTIVE";
    }
    if($sts == 3) {
      $status = "BLOCKED";
    }
   $upsts=mysql_query("UPDATE userdata SET status='$status' WHERE id='$uid'");
   $notifsts = '<font color="ref">Error change user status!</font>';
   if($upsts) {
     $notifsts = '<font color="green">Success change status to '.$status.'!</font>';
  }
}
 $userd=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
 $fuserd=mysql_fetch_array($userd);
 $short=mysql_num_rows(mysql_query("SELECT * FROM urls WHERE userid='$uid'"));
 $advs=mysql_num_rows(mysql_query("SELECT * FROM advertises WHERE userid='$uid'"));
 $invoices=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE userid='$uid'"));

$capts = "Yes";
if(empty($fuserd['captcha'])) {
  $capts = "No";
} 
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Usrer Details
	</div>
	<div class="content">
'.$notifsts.$notifcpt.'
<p>
		&bull; <b>Firstname:</b> '.$fuserd["firstname"].'<p>
<p>
			&bull; <b>Lastname:</b> '.$fuserd["lastname"].'</p>
<p>
			&bull;  <b>Email:</b> '.$fuserd["email"].'</p>
<p>
		&bull; <b>Saldo:</b> Rp '.$fuserd["pubalance"].' (<a href="pub.php?id='.$fuserd["id"].'">Edit</a>)</p>
<p>
			&bull; <b>URLs:</b> <a href="usite.php?id='.$uid.'">'.$short.'</a></p>
<p>
			&bull; <b>Invoices:</b> <a href="uinvo.php?id='.$uid.'">'.$invoices.'</a></p>
			&bull; <b>Status:</b> '.$fuserd['status'].'</p>
<p>
&bull; <b>Change user status:</b>
<select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
<option>-- Select one --</option>
<option value="http://'.$domainUrl.'/admin/user.php?id='.$uid.'&cstatus=2">Inactive</option>
<option value="http://'.$domainUrl.'/admin/user.php?id='.$uid.'&cstatus=1">Active</option>
<option value="http://'.$domainUrl.'/admin/user.php?id='.$uid.'&cstatus=3">Blocked</option>
</select>
</p>
&bull; <b>Captcha:</b> '.$capts.'</p>
<p>
&bull; <b>Change captcha status:</b>
<select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
<option>-- Select one --</option>
<option value="http://'.$domainUrl.'/admin/user.php?id='.$uid.'&captcha=1">Yes</option>
<option value="http://'.$domainUrl.'/admin/user.php?id='.$uid.'&captcha=2">No</option>
</select>
</p>
</div>';
 include '../foot.php';

 }

 else {

 header('Location:login.php');
 }

?>

 