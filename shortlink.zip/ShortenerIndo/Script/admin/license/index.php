<?php


include '../db.php';
include '../functions.php';

if($userlog==1){
   header('Location:/user/dashboard');
   }
  else{
   header('Location:/index.php');
   }
?>