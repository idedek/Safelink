<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel");

if($adminlog==1){


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Admin Panel
	</div>
	<div class="content">';

$auser=mysql_query("SELECT * FROM userdata WHERE status='ACTIVE'");
$tuser=mysql_num_rows(mysql_query("SELECT * FROM userdata"));
$iuser=mysql_query("SELECT * FROM userdata WHERE status='INACTIVE'");
$buser=mysql_query("SELECT * FROM userdata WHERE status='BLOCKED'");
$asite=mysql_query("SELECT * FROM sites WHERE status='<font color=\'green\'>Active</font>'");
$bsite=mysql_query("SELECT * FROM sites WHERE status='BLOCKED'");
$rads=mysql_query("SELECT * FROM advertises WHERE status='RUNNING'");
$pads=mysql_query("SELECT * FROM advertises WHERE status='PENDING'");
$bads=mysql_query("SELECT * FROM advertises WHERE status='REFUSED'");


$ausers=mysql_num_rows($auser);
$iusers=mysql_num_rows($iuser);
$busers=mysql_num_rows($buser);
$asites=mysql_num_rows($asite);
$bsites=mysql_num_rows($bsite);
$rad=mysql_num_rows($rads);
$pad=mysql_num_rows($pads);
$bad=mysql_num_rows($bads);


$chinvo=mysql_query("SELECT * FROM invoice WHERE status='PENDING'");

if(mysql_num_rows($chinvo)>0){
$invo=mysql_num_rows($chinvo);
echo '<p> &bull; <a href="unpayinvo.php"><strong>Ada '.$invo.' invoices</strong> <span>yang belum dibayar bos..!</span></a></p>';
}

$total_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice"));
$paid_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Paid%'"));
$pending_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Pending%'"));
$validated_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Validated%'"));

$total_news=mysql_num_rows(mysql_query("SELECT * FROM news"));
$total_reply=mysql_num_rows(mysql_query("SELECT * FROM newsreplys"));

echo '<div class="border-rule border-bluedark"></div>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/account.png" /> <b><a href="users.php">Users</a></b> <small>('.$tuser.' Total, '.$ausers.' Active, '.$iusers.' Inactive, '.$busers.' Blocked.)</small></p>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/stats_icon.png" /> <b><a href="stats.php">Statistics</a></b></p>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/rate.png" /> <b><a href="rate.php">Rate Per Visit</a></b></p>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/cashout.png" /> <b><a href="invoice.php">Invoices</a></b> <small>('.$total_invo.' Total, '.$paid_invo.' Paid, '.$pending_invo.' Pending, '.$validated_invo.' Validated.)</small></p>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/gambar/seting.png" /> <b><a href="ads.php">Pengaturan Iklan</a></b> <small>(Pengaturan iklan banner, popup & kode histats)</small></p>';

echo '<p><img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/adminout.png" /> <b><a href="logout.php">Logout</a></b></p>
</div>
</div>';
include '../foot.php';


}
else {

header('Location:login.php?redir=index');

}


?>
