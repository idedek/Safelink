<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Invoices");

if($adminlog==1){

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; All Invoices
	</div>
	<div class="content">';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*5;
$end=(5);

$ads=mysql_query("SELECT * FROM invoice ORDER BY id DESC LIMIT $start,$end");
 
 while($sites=mysql_fetch_array($ads)){
  echo '							<table width="100%">
								<tr>
<td>Invoice ID: '.$sites["id"].'<br/>Amount: <b>'.$sites["amount"].'</b><br/>Method: '.$sites["method"].' ('.$sites["via"].')<br/>Name: '.$sites["name"].'<br/>Status: '.$sites["status"].'</td>
</tr></table>
<hr />';
 }
 echo '<center><a href="?page='.($page-1).'">Prev</a> | <a href="?page='.($page+1).'">Next</a></center>';
 echo '
 </div>';
 include '../foot.php';
}
else {
header('Location:index.php');
}
?>