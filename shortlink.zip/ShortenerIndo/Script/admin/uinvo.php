<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Invoices");

if($adminlog==1){

$uid=formget("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Invoices
	</div>
	<div class="content">';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysql_query("SELECT * FROM invoice WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");

while($show=mysql_fetch_array($stat)){
 echo '<p>&bull; Jumlah: '.$show["amount"].'$<br/>&bull; Metode: '.$show["method"].' ('.$show["via"].') ['.$show["status"].']</p><hr />';
 }


echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';


echo '<a href="user.php?id='.$uid.'"><div class="ua" align="center"><b>User Details</b></div></a>
</div>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
