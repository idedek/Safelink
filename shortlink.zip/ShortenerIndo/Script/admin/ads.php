<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Pengaturan Kode Iklan");

if($adminlog==1){
 
 $aid=formget("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Pengaturan kode iklan
	</div>
	<div class="content">';

if(isset($_POST['banerup']) AND isset($_POST['banerdown']) AND isset($_POST['popup']) AND isset($_POST['histats'])){

 $bup1=formpost("banerup");
 $bup=base64_encode($bup1);
 $bdown1=formpost("banerdown"); 
 $bdown=base64_encode($bdown1);
 $pop1=formpost("popup");
 $pop=base64_encode($pop1);
 $histats1=formpost("histats");
 $histats=base64_encode($histats1);
 
 $bupset=mysql_query("UPDATE adscode SET kode='$bup' WHERE id='1'");
 $bdownset=mysql_query("UPDATE adscode SET kode='$bdown' WHERE id='2'");
 $popset=mysql_query("UPDATE adscode SET kode='$pop' WHERE id='3'");
 $histatset=mysql_query("UPDATE adscode SET kode='$histats' WHERE id='4'");

 if($bupset AND $bdownset AND $popset AND $histatset){
   echo '<font color="green">Berhasil!</font><br /><br />';
 }
 else {
  echo 'Error';
 }
 }
 $bokodeup=mysql_query("SELECT * FROM adscode WHERE adstype='banerup'");
$showkodeup=mysql_fetch_array($bokodeup);
$bokodeups1=$showkodeup["kode"];
$bokodeups=base64_decode($bokodeups1);

$bokodedown=mysql_query("SELECT * FROM adscode WHERE adstype='banerdown'");
$showkodedown=mysql_fetch_array($bokodedown);
$bokodedowns1=$showkodedown["kode"];
$bokodedowns=base64_decode($bokodedowns1);

$bokodepop=mysql_query("SELECT * FROM adscode WHERE adstype='popup'");
$showkodepop=mysql_fetch_array($bokodepop);
$bokodepops1=$showkodepop["kode"];
$bokodepops=base64_decode($bokodepops1);

$bokodehistats=mysql_query("SELECT * FROM adscode WHERE adstype='histats'");
$showkodehistats=mysql_fetch_array($bokodehistats);
$bokodehistatss1=$showkodehistats["kode"];
$bokodehistatss=base64_decode($bokodehistatss1);
 echo '<p>&bull; <font color="red">Petunjuk</font>: Jika anda ingin memasang iklan banner, popup, popads atau kode histats agar muncul di halaman shortlink silahkan pasang pada kolom dibawah.</p><div class="registration-login"><form method="post"><b>Banner Atas</b>:<br/><textarea name="banerup" style="resize:none;width:300px;height:100px;">'.$bokodeups.'</textarea><br/><b>Banner Bawah</b>:<br/><textarea name="banerdown" style="resize:none;width:300px;height:100px;">'.$bokodedowns.'</textarea><br/><b>Kode Popup/Popads</b>:<br/><textarea name="popup" style="resize:none;width:300px;height:100px;">'.$bokodepops.'</textarea><br/><b>Kode Histats</b>:<br/><textarea name="histats" style="resize:none;width:300px;height:100px;">'.$bokodehistatss.'</textarea><br/><br /><input class="button" type="submit" value="SET"/></form></div>';
 
 echo '</div>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>