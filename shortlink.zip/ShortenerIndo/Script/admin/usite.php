<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - URLs");

if($adminlog==1){

$uid=formget("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; URLs
	</div>
	<div class="content">';

$page = formget("page");
if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);

$link=mysql_query("SELECT * FROM urls WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");

while($show=mysql_fetch_array($link)){
 echo '<div style="padding-bottom: 7px;">
							<table width="100%">
								<tr>
<td style="text-align: center;" width="38px" rowspan="2">
										<img style="vertical-align: middle; margin-right: 4px;" src="/theme/images/globe.png" />
									</td>
<td><a href="http://'.$_SERVER["HTTP_HOST"].'/'.$show["url_short"].'">http://'.$_SERVER["HTTP_HOST"].'/'.$show["url_short"].'</a></td>
</tr>
<tr>
<td>'.$show["url_link"].'</td>
</tr>
</table><div class="dotted_line"></div>
</div>';
 }


echo '<div style="padding-bottom: 7px;"><center><a href="?id='.$uid.'&page='.($page-1).'">prev</a> | <a href="?id='.$uid.'&page='.($page+1).'">Next</a></center></div>';


echo '<div style="padding-bottom: 7px;">&raquo; <a href="user.php?id='.$uid.'"><b>User Details</b></a></div>
</div>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
