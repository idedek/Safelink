<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Validate Invoice
	</div>
	<div class="content">';

 $vid=formget("id");
 $date=date("d-m-Y");
 $color = '<font color="green">';
 $color2 = '</font>';

 $doit=mysql_query("UPDATE invoice SET status='$color Paid $color2' WHERE id='$vid'");
 if($doit){
   $get_use=mysql_query("SELECT * FROM invoice WHERE id='$vid'");
   $get_us=mysql_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysql_fetch_array($get_u);
   $emailz=$get_user["email"];
   echo '<center><font color="green">Berhasil DIbayar!</font></center>';
       $to      = $emailz;
    $subject = 'Invoice Paid';
    $message = 'Dear '.$get_user["firstname"].',

We are happy to tell you that your invoice ID #'.$vid.' has been successfully Paid!

Thank You!

';
    $headers = 'From: No-Reply<no-reply@'.$urlsite.'>' . "\r\n" .
    'Reply-To: no-reply@'.$urlsite.'' . "\r\n" .
    'X-Mailer: Noreply';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '</div>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>