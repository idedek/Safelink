<?php

include '../db.php';
include '../functions.php';

if($adminlog==1){
header('Location:index.php?error=session');
}
else {

if(isset($_POST['uname']) AND isset($_POST['pwd'])){

$auname=formpost("uname");
$apwd=formpost("pwd");
$apwd=md5($apwd);

$errors=array();

if(!file_exists("license/$auname-data.pra")){
$errors[]='Username was wrong!';
}
$daTa=explode("|-pr-|",file_get_contents("license/$auname-data.pra"));

if($apwd!=md5($daTa[2])){
$errors[]='Password was wrong!';
}

if(strlen($auname)<1){
$errors[]='Username was empty!';
}
if(strlen($apwd)<1){
$errors[]='Password was empty!';
}

if(empty($errors)){

$_SESSION['short_rony']=$auname;
$_SESSION['short_rpw']=$apwd;

header('Location:index.php?login=success');
}
}
headtag("$SiteName - Admin Login");
echo '
<div class="title">&#187; Admin Login</div>
<div class="content">';
dump_error($errors);
echo '
<form method="post"><p>Admin Name:<br/><input type="text" name="uname"/></p><p>Password:<br/><input type="password" name="pwd"/></p><p>
<input class="button" type="submit" value="Log in"/></p></form>
</div>';
}
include '../foot.php';
?>
