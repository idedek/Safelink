<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - SET Rate Visit");

if($adminlog==1){
 
 $aid=formget("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/admin/">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Admin Panel
												</a>
											</td>
										<td width="33%">
												<a class="header_item" href="/admin/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Set Rate Visit
	</div>
	<div class="content">';

if(isset($_POST['rate'])){

 $rode=formpost("rate");
 $errors=array();
 
 if(!is_numeric($rode)){
  echo'<font color="red">Error:</font> Rate harus berupa angka saja, Contoh: <font color="green">10</font><br/><br />';
 }
 else {
 $cset=mysql_query("UPDATE advertises SET rate='$rode' WHERE id='1'");;

 if($cset){
   echo '<font color="green">Rate berhasil di ganti!</font><br /><br />';
 }
 else {
  echo 'Error';
 }
 }
}
 echo '<p>&bull; <font color="red">Petunjuk</font>: Silahkan atur Rate / nilai per visit valid. Misal anda ingin set nilai Rp 20,- per visit, maka masukan 20 (Angka saja)</p><div class="registration-login"><form method="post">Rate Per Visit:<br/><input type="text" name="rate"></input><br/><br /><input class="button" type="submit" value="SET"/></form></div>';
 
 echo '</div>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>