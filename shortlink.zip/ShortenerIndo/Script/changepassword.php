<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Change Password");

if($userlog==1){
$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Ganti Password
	</div>
	<div class="content">';
 $uid=dump_udata("id");

 if(isset($_POST['newpwd1']) AND isset($_POST['newpwd2'])){

  $newpwd1=formpost("newpwd1");
  $newpwd2=formpost("newpwd2");  

  $errors=array();

  if(strlen($newpwd1)<1){
     $errors[]='Password cannot be empty!';
  }
  
  
  if(strlen($newpwd2)<1){
     $errors[]='Verify Password cannot be empty!';
  }

  if($newpwd1!=$newpwd2){
     $errors[]='Passwords did not match!';
   }


   if(empty($errors)){
      $newpwd=md5($newpwd1);
      $uppwd=mysql_query("UPDATE userdata SET password='$newpwd' WHERE id='$uid'");
      if($uppwd){
         echo '<div style="padding-top: 10px; padding-left: 9px;"><font color="green">Password changed!</font>, <a href="/user/login">Please login</a></div>';
       session_destroy();
       }
      else {
         echo 'unk';
       }
    }
    else {
      dump_error($errors);
    }
}
 
echo '
<form method="post">
<p>New Password:<br/>
<input type="password" name="newpwd1"/></p>
<p>Verify New Password:<br/>
<input type="password" name="newpwd2"/></p>
<p>
<input class="button" type="submit" value="Change" /></p>
</form>
</div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>

