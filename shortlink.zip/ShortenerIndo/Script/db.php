<?php

@ini_set('error_log',NULL);

$dbcon=mysql_connect('localhost','dbuser','dbpass');
$dbselect=mysql_select_db('dbname',$dbcon);
$server_name = "http://".$_SERVER['HTTP_HOST']."/";

if(!$dbcon OR !$dbselect){
 echo 'Database connection failed!';
exit;
}

?>