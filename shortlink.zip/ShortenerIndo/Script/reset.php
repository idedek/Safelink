<?php

include 'db.php';
include 'functions.php';
if($userlog==1){
   header('Location:/user/dashboard');
} 

else {

headtag("$SiteName - Reset Password");
  
echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Reset Password</div>
		<div class="content">';

 if(isset($_GET['email']) AND isset($_GET['token'])){
    $user_email=formget("email");
    $token=formget("token");
    
    $errors=array();
    
    $check_im=mysql_query("SELECT * FROM passret WHERE email='$token'");

    if(mysql_num_rows($check_im)<1){
      $errors[]='Email not found!';
    }

    if(mysql_num_rows($check_im)>0){
      

    if(empty($errors)){


    if(isset($_POST['newpwd1']) AND isset($_POST['newpwd2'])){
       $newpwd1=formpost("newpwd1");
       $newpwd2=formpost("newpwd2");
       $errs=array();

     if(strlen($newpwd1)<1){
        $errs[]='Password left empty!';
       }
 
     if(strlen($newpwd2)<1){
        $errs[]='Verify password left empty!';
        }
      
     if($newpwd1!=$newpwd2){
       $errs[]='Passwords didn\'t match!';
        }

     if(empty($errs)){
     
      $newpwd=md5($newpwd1);
      
       $doit=mysql_query("UPDATE userdata SET password='$newpwd' WHERE email='$user_email'");
       
       if($doit){
          echo '&raquo; <font color="green">Password successfully changed! Please</font> <a href="/user/login">login</a>.<br/><br/>';
       }
       else {
          echo '&raquo; <font color="red">Something was wrong!</font><br/><br/>';
       }

      }
      else {
       dump_error($errs);
       }
      }
    echo '
<form method="post">
<p>New Password:<br/><input type="text" name="newpwd1"/></p>
<p>Confirm New Password:<br/><input type="text" name="newpwd2"/></p>
<p><input class="button" type="submit" value="Change Password"/></p>
</form>
</div>';
  }
  else {
   dump_error($errors);
   }
  }
}
}
echo '</div>';
include 'foot.php';

?>
    
      
       
