<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Add Short URL");
if($userlog==1){

$urlto = $domainUrl;
if($custom_domain !== "") {
  $urlto = $custom_domain;
}
 $uid=dump_udata("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Buat Short Link
	</div>
	<div class="content">';
$rates=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE id='1'"));
$ucpc=$rates["rate"];

 if(isset($_POST["url"])){

    $url=formpost("url");
    $url=str_replace('http://',null,$url);
    $url=str_replace('https://',null,$url);
    $short = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 5);



    $errors=array();

    if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$url)){
       $errors[]='Site url is not valid!';
     }



    if(empty($errors)){
       $url='http://'.$url.'';
       $add=mysql_query("INSERT INTO urls (userid, url_link, url_short, status, url_ip) VALUES ('$uid','$url','$short','<font color=\'green\'>Active</font>','".$_SERVER['REMOTE_ADDR']."')");
       if($add){
        echo '<div style="padding-bottom: 12px;">
							<span style="color: #348b00;">
								 Link berhasil dipendekan!
							</span>
						</div>
                                               
							Short URL:<br/>
							<input onclick="this.select();" type="text" value="http://'.$urlto.'/'.$short.'" />
                                                <div style="margin-top: 15px;">
<font color="blue">Silahkan share link yg telah anda pendekan di youtube, facebook, twitter, grup whatsapp atau blog untuk mendapatkan uang!</font></div>
<div style="margin-top: 15px;">
						<div style="padding-bottom: 8px; font-weight: bold;">
								 Tambah Short URL:
							</div></div>
';
       }
       else {
         echo '<div style="padding-bottom: 12px;">
							<span style="color:red;">
								Format URL Error!
							</span>
						</div>';
       }
    }
    else {
     dump_error($errors);
    }
   }
  echo '
<p><b>Short Link (Rp '.$showRate.',- perklik);</b></p>
<form id="form1" name="form1" method="post" action="">
<input type="text" name="url" id="url" placeholder="URL" /></p>
<button class="button">Shorten</button>
</form>
<hr>
<p>&raquo; <a href="/user/mylink">Link Saya</a></p>
</div>
';  
 include 'foot.php';

}

else {

header('Location:/');
}

?>
    