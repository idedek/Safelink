<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Delete URL");

if($userlog==1){

$url=formget("url_short");
$uid=dump_udata("id");
$id=formget("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Delete Link
	</div>
	<div class="content">';

$chsite=mysql_query("SELECT * FROM urls WHERE id='$id' AND url_short='$url'");

if(mysql_num_rows($chsite)>0){
  
      $delsite=mysql_query("DELETE FROM urls WHERE url_short='$url'");
      if($delsite){
        echo '
<p><font color="green">Link deleted successfully!</font> <a href="/user/mylink">Continue</a></p>';
      }
      else {
        echo 'unk';
      }
  echo '';

}
else {
  echo 'As I know you dont own this.';
  }
  echo '<p>&laquo; <a href="/user/mylink">Back to Mylinks</a></p>
</div>';
  
 include 'foot.php';

}
else {
 header('Location:/');
  }

?>
  

     