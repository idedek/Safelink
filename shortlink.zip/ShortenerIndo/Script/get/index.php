<?php

include '../db.php';
include '../functions.php';


$userid=formget("userid");
$shorts=formget("short");
$short=base64_decode($shorts);
// Jika ingin merubah link shortlink menjadi angka & nomor, deleted -> base64_decode

$ipaddress=$_SERVER["REMOTE_ADDR"];
$uagent=$_SERVER["HTTP_USER_AGENT"];
$referer=$_SERVER["HTTP_REFERER"];
 $User=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$userid'"));
$captcha=$User["captcha"];

$captcha_false = "";

if($_POST['short']) {
if($_POST['captcha'] == $_SESSION['security_code'] || empty($captcha)) {
$refr = $_POST['rel'];
$urltidak=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));
$tidak=$urltidak["url_link"];
$urliya=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));
$iya=$urliya["url_link"];

$errors=array();

if(empty($ipaddress)){
$errors[]='a';
}
if(empty($uagent)){
$errors[]='a';
}
if(empty($referer)){
$errors[]='a';
}
$date=date("d-m-Y");

$chIp=mysql_query("SELECT * FROM clicks WHERE ip='$ipaddress' AND time='$date'");

if(mysql_num_rows($chIp)>0){
 $errors[]='a';
}

if(empty($errors)){
 
 $rates=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE id='1'"));
 $ucpc=$rates["rate"];
 $aUser=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$adowner'"));
$userbal=$User["pubalance"];

 $newU=($userbal+$ucpc);

 $doIt1=mysql_query("UPDATE userdata SET pubalance='$newU' WHERE id='$userid'");
 $doIt2=mysql_query("UPDATE affiliates SET balance='$newR' WHERE rid='$userid'");
 $doIt3=mysql_query("INSERT INTO clicks (ip,ua,host,userid,urlid,time,status) VALUES ('$ipaddress','$uagent','$refr','$userid','$short','$date','VALID')");

 if($doIt1 AND $doIt2 AND $doIt3){
   header("Location:$iya");
   exit();
 }
 }
 else {

   $doIt4=mysql_query("INSERT INTO clicks (ip,ua,host,userid,urlid,time,status) VALUES ('$ipaddress','$uagent','$refr','$userid','$short','$date','INVALID')");
   if($doIt4){
    header("Location:$tidak");
    exit();
   }
  }
 } else {
 $captcha_false = '<font color="red">Captcha salah!</font>';
 }
}
$errors=array();

$chSite=mysql_query("SELECT * FROM urls WHERE userid='$userid' AND url_short='$short'");
$chSblock=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));

if(empty($userid)){
$errors[]='Error!';
}
if(empty($short)){
$errors[]='Error!';
}
if(mysql_num_rows($chSite)<1){
$errors[]='Error!';
}
if($chSblock["status"]=="BLOCKED"){
$errors[]='Site is Blocked';
}


if(empty($errors)){

$urls=mysql_query("SELECT * FROM urls WHERE userid='$userid'");
$show=mysql_fetch_array($urls);

$urloke=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));
$oke=$urloke["url_link"];
$title = $oke;
preg_match("/<title>(.+)<\/title>/siU", file_get_contents($title), $matches);
$title = $matches[1];
$sitenames=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
$bkodeup=mysql_query("SELECT * FROM adscode WHERE adstype='banerup'");
$showkodeup=mysql_fetch_array($bkodeup);
$bokodeups1=$showkodeup["kode"];
$bokodeups2=base64_decode($bokodeups1);
$bokodeups3=html_entity_decode($bokodeups2);
$bokodeups=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodeups3);

$bkodedown=mysql_query("SELECT * FROM adscode WHERE adstype='banerdown'");
$showkodedown=mysql_fetch_array($bkodedown);
$bokodedowns1=$showkodedown["kode"];
$bokodedowns2=base64_decode($bokodedowns1);
$bokodedowns3=html_entity_decode($bokodedowns2);
$bokodedowns=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodedowns3);

$bkodepop=mysql_query("SELECT * FROM adscode WHERE adstype='popup'");
$showkodepop=mysql_fetch_array($bkodepop);
$bokodepops1=$showkodepop["kode"];
$bokodepops2=base64_decode($bokodepops1);
$bokodepops3=html_entity_decode($bokodepops2);
$bokodepops=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodepops3);

$bkodehistats=mysql_query("SELECT * FROM adscode WHERE adstype='histats'");
$showkodehistats=mysql_fetch_array($bkodehistats);
$bokodehistatss1=$showkodehistats["kode"];
$bokodehistatss2=base64_decode($bokodehistatss1);
$bokodehistatss3=html_entity_decode($bokodehistatss2);
$bokodehistatss=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodehistatss3);

echo '
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow">
<title>'.$title.'</title>
<meta name="description" content="'.$title.'" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta property="og:type" content="website" />
<meta property="og:title" content="'.$title.'" />
<meta property="og:description" content="'.$title.'" />
<meta property="og:site_name" content="'.$SitaName.'" />
<meta property="og:image" content="http://'.$domainUrl.'/theme/images/share.png" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="/theme/css/blog-post.css" rel="stylesheet">
'.$bokodepops.'
</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">'.$SiteName.'</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="/">Home</a></li>
			<li><a href="/user/login">Masuk</a></li>
                    <li><a href="/user/register">Mendaftar</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
	 <!-- Page Content -->
    <div class="container">
        
        <div class="row">

            <!-- Blog Post Content Column -->
            <div class="col-lg-8">
                <!-- Blog Post -->
	<div style="text-align: center;margin-bottom:8px;">
'.$bokodeups.'
	</div>
	<!-- Title -->
                <h1 style="text-align: center; font-size: 15px; font-weight: bold;margin: 0px;margin-bottom: 10px;">'.$title.'</h1>
	<div style="text-align: center;">
	 '.$bokodeups.'
	</div>
                <hr>
                <div style="text-align: center;">
                  <p>'.$captcha_false.'</p>
                    <div style="display:inline-block;width: 100%;text-align: center;">
                        
	<div class="loading">
                            Silahkan tunggu 8 detik sebelum melanjutkan ... <span class="countdown">8</span> detik.
                            <span class="glyphicon glyphicon-refresh glyphicon-refresh-animate"></span>
                        </div>
<form method="post" id="download" enctype="multipart/form-data" style="display: none;">';
if(!empty($captcha)) {
echo '
<p>Masukan Kode Captcha:</p>
	<img src="/captcha.php" /><br />
    <input style="margin-top:3px;" type="text" name="captcha" maxlength="6" />';
}
echo '
    <input type="hidden" name="short" value="'.$short.'" />
    <input type="hidden" name="rel" value="'.$referer.'" />
    <p><input type="submit" style="background-color: #008cba;color: #ffffff;border: none;height: 30px;min-width: 90px;cursor: pointer;text-align: center;border-radius: 2px;margin:3px;" name="cek" value="Lanjutkan"/></p>
</form>
                    </div>
                </div>
                <hr>
	     <div style="text-align: center;">
	 '.$bokodedowns.'
	</div>
	<div class="col-md-4">
            </div>'; ?>
		<!-- /.row -->
	<!-- Footer -->
        <footer align="center">
            <div class="row">
                <div class="col-lg-6">
                    <p>Copyright &copy; <a href="/"><?php echo $SiteName; ?></a> - 2019</p>
                </div>
				<div class="col-lg-6">
                    <p><a href="//<?php echo $domainUrl; ?>/privacy-policy">Privacy Policy</a> - <a href="//<?php echo $domainUrl; ?>/tos">TOS</a></p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="/theme/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/theme/js/bootstrap.min.js"></script>
	<script>
            $(document).ready(function () {
                $("a.btn-success").hide();

                var doUpdate = function () {
                    $('.countdown').each(function () {
                        var count = parseInt($(this).html());
                        
                        if (count !== 1) {
                            $(this).html(count - 1);
                        } else {
                            $('#download').show();
                            $(".loading").hide();
                        }
                    });
                };

                // Schedule the update to happen once every second
                setInterval(doUpdate, 1500);
            });
		</script>
	<script type="text/javascript">
$(document).ready(function () {
    //Disable cut copy paste
    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
   
    //Disable mouse right click
    $("body").on("contextmenu",function(e){
        return false;
    });
});
</script>
<?php
echo $bokodehistatss;
include('../anticopas.php');
?>
	</body>
</html>

<?php
}
else {

foreach($errors as $error){
echo $error;
}
}

$date=date("d-m-Y");
$chimp=mysql_query("SELECT * FROM imp WHERE uid='$userid' AND date='$date'");
$chimpc=mysql_fetch_array($chimp);
if(mysql_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysql_query("UPDATE imp SET imp='$newimp' WHERE uid='$userid' AND date='$date'");
}
else {
mysql_query("INSERT INTO imp (uid,imp,date) VALUES ('$userid',1,'$date')");
}

?>