<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Terms and Conditions");

$imp=mysql_query("SELECT * FROM imp");
$imps=0;

while($show=mysql_fetch_array($imp)){
$imps=($imps+$show['imp']);
}
$invoice=mysql_query("SELECT * FROM invoice");
$invoices=0;

while($show=mysql_fetch_array($invoice)){
$invoices=($imps+$show['amount']);
}
$site=mysql_num_rows(mysql_query("SELECT * FROM sites"));
if($userlog==1){


echo '
<div class="title">&#187; Terms and Conditions</div>
<div class="content">
<p>1) It is forbidden to add links on '.$urlsite.' that contains illegal content (copyright content, child pornography, threatening, defaming, stalking, abuse, harassing or violating any persons or entitys legal rights)</p>
<p>2) Prohibited any kind of fraud with respect to '.$urlsite.'</p>
<p>3) In case of violation of terms and conditions we reserve the right to delete user including its revenue
</p>
<p>4) We reserve the right to send emails to registered users at any time and/or remove any user at any time without cause and without prior notice and/or remove user revenue at any time without cause and without prior notice
</p>
<p>5) We reserve the right to change our terms and conditions at any time without prior notice to you</p>
</div>';

}
else {
echo '
<div class="title">&#187; Terms and Conditions</div>
<div class="content">
<p>1) It is forbidden to add links on '.$urlsite.' that contains illegal content (copyright content, child pornography, threatening, defaming, stalking, abuse, harassing or violating any persons or entitys legal rights)</p>
<p>2) Prohibited any kind of fraud with respect to '.$urlsite.'</p>
<p>3) In case of violation of terms and conditions we reserve the right to delete user including its revenue
</p>
<p>4) We reserve the right to send emails to registered users at any time and/or remove any user at any time without cause and without prior notice and/or remove user revenue at any time without cause and without prior notice
</p>
<p>5) We reserve the right to change our terms and conditions at any time without prior notice to you</p>';


echo '</div>';

}
include 'foot.php';

?>
