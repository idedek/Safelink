<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - My Account");

if($userlog==1){

 $uid=dump_udata("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Profil Saya
	</div>
	<div class="content">
			<p><img style="vertical-align: middle; margin-right: 10px;" src="/style/images/list.png" /> Firstname: <strong>'.ucfirst(dump_udata("firstname")).'</strong></p>
			<p><img style="vertical-align: middle; margin-right: 10px;" src="/style/images/list.png" /> Lastname: <strong>'.ucfirst(dump_udata("lastname")).'</strong></p>
			<p><img style="vertical-align: middle; margin-right: 10px;" src="/style/images/list.png" /> Email: <strong>'.dump_udata("email").'</strong></p>
			<p><img style="vertical-align: middle; margin-right: 10px;" src="/style/images/list.png" /> Password: <strong>********</strong> (<a href="/user/change_password">Change Password</a>)</p>
</div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>




