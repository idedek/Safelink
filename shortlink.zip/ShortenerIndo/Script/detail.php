<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Link Details");

if($userlog==1){

$urlto = $domainUrl;
if($custom_domain !== "") {
  $urlto = $custom_domain;
}
$url=formget("url_short");

$uid=dump_udata("id");


$chsite=mysql_query("SELECT * FROM urls WHERE userid='$uid' AND url_short='$url'");

if(mysql_num_rows($chsite)>0){
while($show=mysql_fetch_array($chsite)){


echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Link Detail
	</div>
	<div class="content">
<p>URL Short:<br/>
							<input onclick="this.select();" type="text" value="http://'.$urlto.'/'.$url.'" /></p>
<p>
Original URL:<br/>
							<input onclick="this.select();" type="text" value="'.$show["url_link"].'" /></p>
<p>Share on</p>
							
							<img style="vertical-align: middle; margin-right: 5px;" src="/theme/images/fbshare.png" /> <a target="_blank" href="http://m.facebook.com/sharer.php?u=http://'.$urlto.'/'.$url.'">Facebook</a>
							<img style="vertical-align: middle; margin-left: 15px; margin-right: 5px;" src="/theme/images/gplus.png" /> <a target="_blank" href="https://plus.google.com/share?url=http://'.$urlto.'/'.$url.'">Google</a>
							<img style="vertical-align: middle; margin-left: 15px; margin-right: 5px;" src="/theme/images/twitter.png" /> <a target="_blank" href="https://twitter.com/intent/tweet?url=http://'.$urlto.'/'.$url.'">Twitter</a>
<div class="dotted_line"></div>';
}
}
else {
echo '<div class="error">You do not own this URLs!</div>';
}

echo '<p><a href="/user/mylink">&laquo; Back to Mylinks</a>.</p>
</div>';

include 'foot.php';
}
else {

header('Location:/');
}
?>
