<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Advertisement management");

if($userlog==1){
echo '<div class="container">';

$uid=dump_udata("id");

$adver=mysql_query("SELECT * FROM advertises WHERE userid='$uid'");

if(mysql_num_rows($adver)>0){
while($show=mysql_fetch_array($adver)){
echo '<p><div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/list.png" /> Judul: <b>'.$show["name"].'</b>
</div>
<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/list.png" /> URL: <b>'.$show["url"].'</b>
</div>
<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/list.png" /> Device: <b>'.$show["device"].'</b>
</div>
<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/list.png" /> Target: <b>'.$show["country"].'</b>
</div>
<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/theme/images/list.png" /> Status: <b>'.$show["status"].'</b>
</div></p>';
}
}
else {

echo '<div class="ad">There is no Ad created by you!</div>';

}

echo '<center><a href="/user/tambah-juragan"><input type="submit" class="button" value="Create new Ad"/></a></center>';

echo '</div>';

include 'foot.php';

}

else {


header('Location:/');

}

?>

