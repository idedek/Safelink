<?php
include 'db.php';
include 'functions.php';
if($userlog==1){
header("location:/user/dashboard/");
}
else {
  if(isset($_POST['user_email']) AND isset($_POST['user_pwd'])){
     
     $user_email=formpost("user_email");
     $user_pwd=formpost("user_pwd");
     $user_password=md5($user_pwd);

     $errors=array();

     $login_check=mysql_query("SELECT * FROM userdata WHERE email='$user_email'");
     
     if(mysql_num_rows($login_check)<1){
        $errors[]='No such user with this email!';
     }
 
     if(mysql_num_rows($login_check)>0){
        $login_check2=mysql_fetch_array($login_check);
        
        if($login_check2['password']!=$user_password){
           $errors[]='Password entered was wrong!';
        }
      }

     if(strlen($user_email)<1){
       $errors[]='Please enter your email!';
      }

     if(strlen($user_pwd)<1){
       $errors[]='Please enter your password!';
     }
     if(empty($errors)){
       $_SESSION['short_email']=$user_email;
       $_SESSION['short_password']=$user_password;
       header("location:/user/dashboard/");
     }
     else {
          foreach($errors as $error){
          $derror .= ''.$error.'<br/>';
          }
     }
   }
headtag("$SiteName - Login");

   echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Masuk</div>
		<div class="content">';
if($derror) {
          echo '<div style="padding-bottom: 12px; color: #c90000;">
          '.$derror.'
          </div>';
}
echo '

<form method="post">
Email:<br/>
<input type="text" name="user_email"/><br/>
Password:<br/>
<input type="password" name="user_pwd"/><br/>

<input class="button" type="submit" value="Masuk">
</form>
<div style="height: 15px;"></div>
					
					<img style="vertical-align: middle;" src="/style/images/Help-2-16.png" /> <a href="/forgot.php">Lupa Password?</a>

</div>
';

}

include 'foot.php';
?>
