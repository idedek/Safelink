<?php

session_start();
error_reporting(0);

date_default_timezone_set('Asia/Jakarta');
//Modify these lines and go to hell!
//This Script Created by r00td4nZ, Please don't remove Copyright ^_^

$SiteName=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
$urlsite=$_SERVER["HTTP_HOST"];
function headtag($headtitle) {
if(empty($headtitle)){
$headtitle=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
}
$sitenames=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.png" />
<title>'.$headtitle.'</title>
<meta name="description" content="LinkDuit.mobi - Pemendek URL Terpercaya Penghasil Uang dan Pulsa. Pendekan link URL, bagikan dan dapatkan Rupiah yang bisa di tukarkan menjadi Pulsa atau langsung tarik ke rekening Bank Mu.">
<meta name="keywords" content="pemendek url, url shortener, linkduit, pemendek url terpercaya, url shortener dibayar pulsa">
<link rel="stylesheet" type="text/css" href="/theme/css/style2.css" />
</head>
<body>
<div class="logo">
			<a href="/"><img style="vertical-align: middle; margin-right: 5px;" src="/style/images/logo.png" /></a>
	</div>
';

$getData=mysql_query("SELECT * FROM invoice WHERE status LIKE '%Paid%' ORDER BY id DESC LIMIT 1");

while($fetchData=mysql_fetch_array($getData)){

echo '
		<div style="padding-top: 5px; padding-bottom: 5px;">
		<marquee><b>Update Pembayaran: <font color="blue">PO#'.$fetchData['id'].'</font> Via '.$fetchData['method'].' <font color="green">Rp '.number_format($fetchData['amount'],"0",",",".").'</font> ('.substr($fetchData["via"],0,9).'</font><font color="red">xxx</font>) => <font color="green">SUKSES</font></b></marquee>
		</div>';

}
$news=mysql_query("SELECT * FROM news ORDER BY id DESC");
$newsf=mysql_fetch_array($news);


}

$rateSql = mysql_query("SELECT rate FROM advertises WHERE id = 1");
while($dataRate = mysql_fetch_array($rateSql))
{ $showRate = $dataRate['rate'];
}

function formget($val){
$val2=$_GET["$val"];
$get=mysql_real_escape_string(addslashes(htmlspecialchars($val2)));
return $get;
}

function formpost($val1){
$val3=$_POST["$val1"];
$post=mysql_real_escape_string(addslashes(htmlspecialchars($val3)));
return $post;
}
function dump_error($erro){
echo '<div class="error">';
foreach($erro as $errr){
echo ''.$errr.'<br/>';
}
echo '</div>';
}
function dump_udata($udataname){
$uemail=mysql_real_escape_string($_SESSION['short_email']);

$udata=mysql_query("SELECT * FROM userdata WHERE email='$uemail'");
$ufdata=mysql_fetch_array($udata);
return $ufdata["$udataname"];
}


$chssuser=mysql_real_escape_string($_SESSION['short_email']);
$chsspass=mysql_real_escape_string($_SESSION['short_password']);
$chsslog=mysql_query("SELECT * FROM userdata WHERE email='$chssuser'");
$admu=mysql_real_escape_string($_SESSION['short_rony']);
$admp=mysql_real_escape_string($_SESSION['short_rpw']);

if(file_exists("license/$admu-data.pra")){
$rpC=explode("|-pr-|",file_get_contents("license/$admu-data.pra"));
if($admp==md5($rpC[2])){
$main_adm=file_get_contents("license/main-admin.pran");
if($admu==$main_adm){
$admin_id='pranto';
}
$adminlog=1;
}
}
else {
$adminlog=0;
}

if(mysql_num_rows($chsslog)>0){
$dumlog=mysql_fetch_array($chsslog);
if($dumlog["password"]==$chsspass){
$userlog=1;
if(preg_match('/block/',strtolower($dumlog["status"]))){

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>'.$headtitle.'</title>
<link rel="stylesheet" type="text/css" href="/theme/css/style2.css" />
</head>
<body>
<div class="logo">
			<a href="/"><img style="vertical-align: middle; margin-right: 5px;" src="/style/images/logo.png" /></a>
	</div>
		<div class="title">
		&#187; Account Blocked
	</div>
	<div class="content"><center>
<font color="red">Your Account has blocked!</b></font></p><p><b>Reason: '.str_replace('blocked',null,$dumlog["status"]).'.</b></p></center></div>';
include 'foot.php';
exit;
}
}
else {
$userlog=0;
}
}


?>
