<?php

session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
//Modify these lines and go to hell!

$SiteName=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
$urlsite=$_SERVER["HTTP_HOST"];
function headtag($headtitle) {
if(empty($headtitle)){
$headtitle=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
}
$sitenames=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<title>'.$headtitle.'</title>
<link rel="stylesheet" type="text/css" href="/theme/asset/main.css" />
<link rel="stylesheet" type="text/css" href="/theme/css/styles.css" />
<link rel="stylesheet" href="/boost.css">

</head>
<body>
<table class="bagian-kepala home">
    <tbody><tr>
        <td class="logo_kepala">
            <a href="/"><h3 style="color: white">'.$sitenames.'</h3></a>
        </td>

    </tr>
</tbody></table>
<div style="padding-top: 5px; padding-left: 5px;">';

$rateSql = mysql_query("SELECT rate FROM advertises WHERE id = 1");
while($dataRate = mysql_fetch_array($rateSql))
{
$showRate = $dataRate['rate'];
echo '
		<font color="red">Script Short URL | Rate Rp.'.$showRate.'/Klik Valid</font>
<br />
Minat? beli disini gan:
<br />
<a href="https://facebook.com/zidan.ananda.4/">Facebook</a>
<br />
WA: 08567037432
		</div>
';
}
$news=mysql_query("SELECT * FROM news ORDER BY id DESC");
$newsf=mysql_fetch_array($news);


}

function formget($val){
$val2=$_GET["$val"];
$get=mysql_real_escape_string(addslashes(htmlspecialchars($val2)));
return $get;
}

function formpost($val1){
$val3=$_POST["$val1"];
$post=mysql_real_escape_string(addslashes(htmlspecialchars($val3)));
return $post;
}
function dump_error($erro){
echo '<div class="error">';
foreach($erro as $errr){
echo ''.$errr.'<br/>';
}
echo '</div>';
}
function dump_udata($udataname){
$uemail=mysql_real_escape_string($_SESSION['short_email']);

$udata=mysql_query("SELECT * FROM userdata WHERE email='$uemail'");
$ufdata=mysql_fetch_array($udata);
return $ufdata["$udataname"];
}


$chssuser=mysql_real_escape_string($_SESSION['short_email']);
$chsspass=mysql_real_escape_string($_SESSION['short_password']);
$chsslog=mysql_query("SELECT * FROM userdata WHERE email='$chssuser'");
$admu=mysql_real_escape_string($_SESSION['short_rony']);
$admp=mysql_real_escape_string($_SESSION['short_rpw']);

if(file_exists("license/$admu-data.pra")){
$rpC=explode("|-pr-|",file_get_contents("license/$admu-data.pra"));
if($admp==md5($rpC[2])){
$main_adm=file_get_contents("license/main-admin.pran");
if($admu==$main_adm){
$admin_id='pranto';
}
$adminlog=1;
}
}
else {
$adminlog=0;
}

if(mysql_num_rows($chsslog)>0){
$dumlog=mysql_fetch_array($chsslog);
if($dumlog["password"]==$chsspass){
$userlog=1;
if(preg_match('/block/',strtolower($dumlog["status"]))){



echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<title>'.$headtitle.'</title>
<link rel="stylesheet" type="text/css" href="/theme/css/styles.css" />
</head>
<body class="">
<div class=" desktop">
<div class="wrapper">
<table class="bagian-kepala home">
    <tr>
        <td class="logo_kepala">
            <a href="/"><img src="/theme/images/logo.png" alt="9ad.me" /></a>
        </td>
        <td class="url_contoh">
            <a href="#"><font color="white">Example</font></a>
        </td>
    </tr>
</table>';

echo '<div class="container"><p><b><font color="red">Your Account has blocked!</b></font></p><p><b>Reason: '.str_replace('blocked',null,$dumlog["status"]).'.</b></p>.</div>';
include 'foot.php';
exit;
}
}
else {
$userlog=0;
}
}


?>
