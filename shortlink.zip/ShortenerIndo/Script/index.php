<?php
include 'db.php';
include 'functions.php';

$slogan = "- Pemendek URL Penghasil Uang dan Pulsa";

$q = '<font color="green"> Paid </font>';


$invoice=mysql_query("SELECT * FROM invoice");
$invoices=0;

while($show=mysql_fetch_array($invoice)){
$invoices=($invoices+$show['amount']);
}
$shortn=mysql_num_rows(mysql_query("SELECT * FROM urls"));
$members=mysql_num_rows(mysql_query("SELECT * FROM userdata"));
if($userlog==1){
$uid=dump_udata("id");
if(dump_udata("status")!=='INACTIVE'){
header('Location:/user/dashboard');
} else {
headtag("$SiteName $slogan");
echo '
<div class="content">
<center><font color="red"><b>Account Inactive !</b></font><br/><br/>Your account is inactive. Please check <u>INBOX</u> or <u>SPAM</u> folder on your email account, and click on the activation link sent to your email to activate your account!</center>';
echo '</div>';
}
} else {
headtag("$SiteName $slogan");
echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
				&#187; Bagaimana Mendapat Uang & Pulsa di '.$SiteName.'?
		</div>
		<div style="padding-top: 15px; padding-bottom: 35px;">
				<div style="text-align: center; padding-bottom: 30px;">
					<img style="vertical-align: middle; margin-right: 3px;" src="/style/images/icon_12x12_info.png" /> Pendekan link mu di '.$SiteName.', Share short link di Blog kamu & Dapatkan Rp '.$showRate.',- per visitor valid. Saldo dapat ditarik melalui Pulsa, Paypal atau Bank.  
				</div>
				<div style="padding-bottom: 40px;">
				<center>
						<table width="250px">
							<tbody>									
									<tr>
									<td style="vertical-align: top; width: 100%; text-align: center;">
										<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&width=100&layout=button_count&action=like&show_faces=false&share=false&height=35" style="border: none; overflow: hidden; width: 100px; height: 35px;"></iframe>
									</td>
								</tr>
									<tr>
									<td style="vertical-align: top; width: 100%; text-align: center;">
										<img src="/style/images/678131-money-16.png"> Update Bukti Pembayaran: <a href="/bukti-pembayaran"><b>Klik Disini</b></a>
									</td>
								</tr>
							</tbody>
						</table>
					</center>
				</div>
';

$getData=mysql_query("SELECT * FROM invoice WHERE status LIKE '%$q%' ORDER BY id DESC LIMIT 1");

while($fetchData=mysql_fetch_array($getData)){
echo '<center></center>';
}
echo '
				<table width="100%">
					<tbody>
						<tr>
							<td width="33%" valign="top" style="text-align: center;">
								<img src="/style/images/icon_42x42_link.png" />
								
								<div style="margin-top: 4px;">
									 '.number_format($shortn).'
								</div>
								<div style="margin-top: 4px;">
									Total Link
								</div>
							</td>
							<td width="34%" valign="top" style="text-align: center;">
								<img src="style/images/click.png" width="42px" height="42px" />
								
								<div style="margin-top: 4px;">
									Rp '.number_format($invoices).',-
								</div>
								<div style="margin-top: 4px;">
									Pembayaran
								</div>
							</td>
							<td width="33%" valign="top" style="text-align: center;">
								<img src="/style/images/marty-mcfly-64.png" width="42px" height="42px" />
								
								<div style="margin-top: 4px;">
									 '.number_format($members).'
								</div>
								<div style="margin-top: 4px;">
									Member
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
';

}

include 'foot.php';
?>
