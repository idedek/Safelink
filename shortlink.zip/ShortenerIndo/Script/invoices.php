<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Payment Message");

if($userlog==1){


$uid=dump_udata("id");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Status Pembayaran
	</div>
	<div class="content">';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);

$invo=mysql_query("SELECT * FROM invoice WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");
if(mysql_num_rows($invo)>0){
echo '
<div>
<table class="table" width="100%" cellpadding="0" cellspacing="0">
       <thead>
		<tr>
	           <th width="25%">ID</th>
                   <th width="25%">Amount</th>
                   <th width="25%">Method</th>
                   <th width="25%">Status</th>
               </tr>
       </thead>
<tbody>';
while($show=mysql_fetch_array($invo)){
  echo '
  <tr>
    <td style="text-align: center; padding: 20px;" colspan="0%">#'.$show["id"].'</td>
    <td style="text-align: center; padding: 20px;" colspan="0%">Rp '.$show["amount"].'</td>
    <td style="text-align: center; padding: 20px;" colspan="0%">'.$show["method"].'</td>
    <td style="text-align: center; padding: 20px;" colspan="0%">'.$show["status"].'</td>
  </tr>
';
}
echo '</tbody>
	</table>
<center><a href="/user/invoices?page='.($page-1).'">&laquo; Prev</a> - <a href="/user/invoices?page='.($page+1).'">Next &raquo;</a></center></div>
';
 }
else {

echo '<br /><center><font color="red">There is no invoice!</font></center><br />';
}

echo '</div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
