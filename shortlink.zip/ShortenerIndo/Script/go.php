<?php

include 'db.php';
include 'functions.php';


$userid=formget("userid");
$url=formget("url");
$short = $url;
$juduluc=formget("url");
$judulku = $juduluc;
$haseum = array(".apk", ".rar", ".zip", ".3gp", ".mp3", ".mp4", ".srt", ".png", ".jpg", ".mkv", ".jar", ".exe", ".gzip", ".gif", ".txt", ".7z");
$judul = str_replace($haseum, "", $judulku);
preg_match("/<title>(.+)<\/title>/siU", file_get_contents($judul), $matches);
$judul = $matches[1];
if(empty($judul)){
$judul=formget("url");
}
$errors=array();

$members=mysql_query("SELECT * FROM userdata WHERE id='$userid'");

if(empty($userid)){
$errors[]='user Error!';
}
if(empty($url)){
$errors[]='url Error!';
}
if(mysql_num_rows($members)<1){
$errors[]='Error!';
}


if(empty($errors)){


$ipaddress=$_SERVER["REMOTE_ADDR"];
$uagent=$_SERVER["HTTP_USER_AGENT"];
$referer=$_SERVER["HTTP_REFERER"];

$sitenames=file_get_contents('http://'.$_SERVER["HTTP_HOST"].'/sitename.txt');
$bkodeup=mysql_query("SELECT * FROM adscode WHERE adstype='banerup'");
$showkodeup=mysql_fetch_array($bkodeup);
$bokodeups1=$showkodeup["kode"];
$bokodeups2=base64_decode($bokodeups1);
$bokodeups3=html_entity_decode($bokodeups2);
$bokodeups=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodeups3);

$bkodedown=mysql_query("SELECT * FROM adscode WHERE adstype='banerdown'");
$showkodedown=mysql_fetch_array($bkodedown);
$bokodedowns1=$showkodedown["kode"];
$bokodedowns2=base64_decode($bokodedowns1);
$bokodedowns3=html_entity_decode($bokodedowns2);
$bokodedowns=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodedowns3);

$bkodepop=mysql_query("SELECT * FROM adscode WHERE adstype='popup'");
$showkodepop=mysql_fetch_array($bkodepop);
$bokodepops1=$showkodepop["kode"];
$bokodepops2=base64_decode($bokodepops1);
$bokodepops3=html_entity_decode($bokodepops2);
$bokodepops=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodepops3);

$bkodehistats=mysql_query("SELECT * FROM adscode WHERE adstype='histats'");
$showkodehistats=mysql_fetch_array($bkodehistats);
$bokodehistatss1=$showkodehistats["kode"];
$bokodehistatss2=base64_decode($bokodehistatss1);
$bokodehistatss3=html_entity_decode($bokodehistatss2);
$bokodehistatss=str_ireplace(array("\r","\n",'\r','\n'),'', $bokodehistatss3);

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<title>'.$judul.'</title>
<link rel="stylesheet" type="text/css" href="/theme/css/styles.css" />
'.$bokodepops.'
</head>
<body class="">
<div class=" desktop">
<div class="wrapper">
<table class="bagian-kepala home">
    <tr>
        <td class="logo_kepala">
            <a href="/"><font color="white">'.$sitenames.'</font></a>
        </td>
        <td class="url_contoh">
            <font color="white">Pemendek URL Penghasil Rupiah</font>
        </td>
    </tr>
</table>
<div class="container">
<p align="center">'.$judul.'</p>
<center>'.$bokodeups.'</center>
<div style="margin-bottom:2px;"></div>
<center><form action="/proses.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="userid" value="'.$userid.'">
        <input type="hidden" name="ipaddress" value="'.$ipaddress.'">
        <input type="hidden" name="short" value="'.$short.'">
        <input type="hidden" name="uagent" value="'.$uagent.'">
        <input type="hidden" name="referer" value="'.$referer.'">
        <input class="button" type="submit" name="submit" value="Get Link">
      </form></center>
      <div style="margin-top:6px;"></div>
      
      
<p align="center">'.$bokodedowns.'</p>
<div class="alinea"></div>';
echo '</div>
<center>'.$bokodehistatss.'</center>
<table class="footer-area footer tiga-kolom">
    <tr>
        <td class="columns__left">
            <a href="/terms-conditions">
                Terms
            </a>
        </td>
        <td class="columns__center">
            <a href="/privacy-policy">
                Privacy Policy
            </a>
        </td>
        <td class="columns__right">
            <a href="/contact">
                Contact
            </a>
        </td>
    </tr>
</table>
<div class="footer-area footer-copyright footer-border">
                    <span>2017</span> <span>All rights reserved.</span>
                </div>
</div>
</div>';
include 'anticopas.php';
echo '</body>
</html>
';


}
else {

foreach($errors as $error){
echo $error;
}
}

$date=date("d-m-Y");
$chimp=mysql_query("SELECT * FROM imp WHERE uid='$userid' AND date='$date'");
$chimpc=mysql_fetch_array($chimp);
if(mysql_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysql_query("UPDATE imp SET imp='$newimp' WHERE uid='$userid' AND date='$date'");
}
else {
mysql_query("INSERT INTO imp (uid,imp,date) VALUES ('$userid',1,'$date')");
}

?>