<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Referral");

if($userlog==1){

 $uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Dapatkan 20% dari setiap penghasilan Referral Kamu
	</div>
	<div class="content">
<table width="100%" cellpadding="0" cellspacing="0">
			<tbody>
				<tr>
					<td width="100%" style="text-align: left;">'; $add=mysql_query("SELECT SUM(balance) from affiliates WHERE aid='$uid'");
while($row1=mysql_fetch_array($add))
{
    $mark=$row1['SUM(balance)'];
    $mark1=($mark*0.10);
echo '
						<img style="vertical-align: middle; margin-right: 5px;" src="/theme/images/cashout.png" /> Total Bonus: <b>Rp '.$mark1.',-</b>';
}
echo '
</td>
				</tr>
			</tbody>
		</table>
<div class="dotted_line"></div>
&#187; Penghasilan referral otomatis akan ditambahkan ke saldo utama setelah mencapai <b>Rp10.000,-</b>.
<div class="dotted_line"></div>
Your Referral Link

<input onclick="this.select();" type="text" value="http://'.$_SERVER["HTTP_HOST"].'/join/ref/'.$uid.'" />

<div class="dotted_line"></div>
<b>Share on: </b>
							
							<img style="vertical-align: middle; margin-right: 5px;" src="/theme/images/fbshare.png" /> <a target="_blank" href="http://m.facebook.com/sharer.php?u=http://'.$_SERVER["HTTP_HOST"].'/join/ref/'.$uid.'">Facebook</a>
							<img style="vertical-align: middle; margin-left: 15px; margin-right: 5px;" src="/theme/images/gplus.png" /> <a target="_blank" href="https://plus.google.com/share?url=http://'.$_SERVER["HTTP_HOST"].'/join/ref/'.$uid.'">Google</a>
							<img style="vertical-align: middle; margin-left: 15px; margin-right: 5px;" src="/theme/images/twitter.png" /> <a target="_blank" href="https://twitter.com/intent/tweet?url=http://'.$_SERVER["HTTP_HOST"].'/join/ref/'.$uid.'">Twitter</a>
<div class="dotted_line"></div>
<p>Statistik Referral</p>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);

$invo=mysql_query("SELECT * FROM affiliates WHERE aid='$uid' ORDER BY id DESC LIMIT $start,$end");
if(mysql_num_rows($invo)>0){
echo '
<div>
<table class="table" width="100%" cellpadding="0" cellspacing="0">
       <thead>
		<tr>
	           <th width="33%">Userid</th>
                   <th width="34%">Name</th>
                   <th width="34%">Earning (10%)</th>
               </tr>
       </thead>
<tbody>';
while($show=mysql_fetch_array($invo)){
$earn=$show["balance"];
$refearn=($earn*0.10);
  echo '
  <tr>
    <td style="text-align: center; padding: 20px;" colspan="0%">'.$show["rid"].'</td>
    <td style="text-align: center; padding: 20px;" colspan="0%">'.$show["firstname"].'</td>
    <td style="text-align: center; padding: 20px;" colspan="0%">$'.$refearn.'</td>
  </tr>
';
}
echo '</tbody>
	</table>
<a href="/user/referral?page='.($page-1).'">&laquo; Pref</a> - <a href="/user/referral?page='.($page+1).'">Next &raquo</a></div>
';
 }
else {

echo '<br /><font color="red">Anda Belum Memiliki Satupun Referral !</font><br />';
}

echo '</div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>

