<?php
include 'db.php';
include 'functions.php';

 if($userlog==1){
   header('Location:/user/dashboard');
   }
  else{
headtag("$SiteName - Registration");

echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Pendaftaran</div>
		<div class="content">';
$ref=formget("ref");
$chsite=mysql_query("SELECT * FROM userdata WHERE id='$ref'");
if(mysql_num_rows($chsite)<1){

echo '<font color="red">Referral Code is Invalid !!!</font><br />You will redirect to default registration page.<br /><br /><meta http-equiv="Refresh" content="3; URL=/user/registration">';
}
       if(isset($_POST['firstname']) AND isset($_POST['lastname']) AND isset($_POST['email']) AND isset($_POST['password1']) AND isset($_POST['password2'])){


$firstname=formpost("firstname");
$lastname=formpost("lastname");
$country=formpost("country");
$email=formpost("email");
$password1=formpost("password1");
$password2=formpost("password2");
//Codes
$errors=array();
unset($errors);

//Empty
if(mysql_num_rows($chsite)<1){
$errors[]='First name field left empty!';
}

if(strlen($firstname)<1){
$errors[]='First name field left empty!';
}

if(strlen($lastname)<1){
$errors[]='Last name field left empty!';
}

if(strlen($email)<1){
$errors[]='Email field left empty!';
}

if(strlen($password1)<1){
$errors[]='Password field left empty!';
}


if(strlen($password2)<1){
$errors[]='Verify password field left empty!';
}


if(!preg_match('/^([a-zA-Z0-9_.-]+)\@([a-zA-Z0-9_.-]+)\.([a-zA-Z0-9_.-]+)$/', $email)){
$errors[]='Email is not valid!';
}

if($password1!=$password2){
$errors[]='Passwords didn\'t match!';
}

$emch=mysql_query("SELECT * FROM userdata WHERE email='$email'");

if(mysql_num_rows($emch)>0){
$errors[]='Email already registered with another account!';
}

if(empty($errors)){
  $password=md5($password1);
  $doreg=mysql_query("INSERT INTO userdata (email,password,firstname,lastname,status,pubalance) VALUES ('$email','$password','$firstname','$lastname','ACTIVE','0.00')");

  if($doreg){
$user_data=mysql_query("SELECT * FROM userdata WHERE email='$email'");
$userdat=mysql_fetch_array($user_data);
$rid=$userdat['id'];
$doref=mysql_query("INSERT INTO affiliates (aid,rid,status,firstname,lastname,balance) VALUES ('$ref','$rid','ACTIVE','$firstname','$lastname','0.00')");
$_SESSION['short_email']=$email;
$_SESSION['short_password']=$password;

header('Location:/user/dashboard');
}
else {
echo '<font color="red">Email already registered with another account!</font><br /><br />';
}
}
else {

echo '<div style="padding-bottom: 12px; color: #c90000;">';

foreach($errors as $error){
echo '- '.$error.'<br/>';
}
echo '</div>';
}
    

//END

}


echo '
<form method="post">
<p>First Name:<font color="red">*</font><br/><input type="text" name="firstname"/></p>
<p>Last name:<font color="red">*</font><br/><input type="text" name="lastname"/></p>
<p>Email:<font color="red">*</font><br/><input type="text" name="email"/></p>
<p>Password:<font color="red">*</font><br/><input type="password" name="password1"/></p>
<p>Verify Password:<font color="red">*</font><br/><input type="password" name="password2"/></p>
<p>By clicking "Register", you agree to our <a href="/terms-conditions">Terms</a> and that you have read our <a href="/privacy-policy">Privacy Policy</a>, including our Cookie Use.</p>
<p><input class="button" type="submit" value="Register" /></p>
</form>
</div>';

}

include 'foot.php';

?>
       