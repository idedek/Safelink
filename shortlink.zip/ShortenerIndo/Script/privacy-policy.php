<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Privacy Policy");

$imp=mysql_query("SELECT * FROM imp");
$imps=0;

while($show=mysql_fetch_array($imp)){
$imps=($imps+$show['imp']);
}
$invoice=mysql_query("SELECT * FROM invoice");
$invoices=0;

while($show=mysql_fetch_array($invoice)){
$invoices=($imps+$show['amount']);
}
$site=mysql_num_rows(mysql_query("SELECT * FROM sites"));
if($userlog==1){
echo '
<div class="title">&#187; Privacy Policy</div>
<div class="content"> 
<p><b>What Information Do We Collect?</b></p>
<p>We collect information such as your browser detail, IP address and referrer details to monitor server traffic. This information is never shared or sold. This information is used to analyze traffic.</p>
<div class="border-rule border-bluedark"></div>
<p><b>Third Party Advertising</b></p>
<p>We use Google Adsense and other third-party advertising service to serve ads when you visit our Website. These companies may use information (not including your name, address, email address or telephone number) about your visits to this and other Web sites in order to provide advertisements on this site and other sites about goods and services that may be of interest to you. If you would like more information about this practice and to know your choices about not having this information used by these companies, please visit their privacy policies. There are third Party Cookies in the course of serving advertisements to this site, our third-party advertiser may place or recognize a unique "cookie" on your browser. We also use ads out of interest-based advertising. Google use of the DART cookie enables it to serve ads to your users based on their visit to your sites and other sites on the Internet. Users can opt out of the use of the DART cookie by visiting the Google ad network privacy policy. </p>
</div>
';

}
else {
echo '
<div class="title">&#187; Privacy Policy</div>
<div class="content"> 
<p><b>What Information Do We Collect?</b></p>
<p>We collect information such as your browser detail, IP address and referrer details to monitor server traffic. This information is never shared or sold. This information is used to analyze traffic.</p>
<div class="border-rule border-bluedark"></div>
<p><b>Third Party Advertising</b></p>
<p>We use Google Adsense and other third-party advertising service to serve ads when you visit our Website. These companies may use information (not including your name, address, email address or telephone number) about your visits to this and other Web sites in order to provide advertisements on this site and other sites about goods and services that may be of interest to you. If you would like more information about this practice and to know your choices about not having this information used by these companies, please visit their privacy policies. There are third Party Cookies in the course of serving advertisements to this site, our third-party advertiser may place or recognize a unique "cookie" on your browser. We also use ads out of interest-based advertising. Google use of the DART cookie enables it to serve ads to your users based on their visit to your sites and other sites on the Internet. Users can opt out of the use of the DART cookie by visiting the Google ad network privacy policy. </p>
</div>
';

}
include 'foot.php';

?>
