<?php
include 'db.php';
include 'functions.php';

if($userlog==1){

session_destroy();

header('Location:/user/login');
}
else {
header('Location:/');
}
?>
