        <div style="text-align: center;" class="footer">
			<center>
				<div style="width: 100%;">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tbody>
							<tr>
								<td width="34%">
									<a target="_blank" class="footer_item" href="/terms-conditions">
										Terms
									</a>
								</td>
								<td width="33%">
									<a class="footer_item" href="/privacy-policy">
										Privacy Policy
									</a>
								</td>
								<td width="33%">
									<a target="_blank" class="footer_item" href="/contact">
										Contact
									</a>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</center>
		</div>
<div style="padding-top: 20px; text-align: center;">
                    &#169; <?php echo $_SERVER['HTTP_HOST']; ?> | All rights reserved.
                </div>
				

</body>
</html>