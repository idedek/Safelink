<?php

if(!$_GET['step']){

//STEP 1 Start

if(isset($_POST['db_server']) AND isset($_POST['db_user']) AND isset($_POST['db_pass']) AND isset($_POST['db_name']) AND isset($_POST['sitename'])){

 $sitename=$_POST['sitename'];
 $db_server=$_POST['db_server'];
 $db_user=$_POST['db_user'];
 $db_pass=$_POST['db_pass'];
 $db_name=$_POST['db_name'];

$filename = 'localhost.sql';

$mysql_host = $db_server;
// MySQL username
$mysql_username = $db_user;
// MySQL password
$mysql_password = $db_pass;
// Database name
$mysql_database = $db_name;

// Connect to MySQL server
mysql_connect($mysql_host, $mysql_username, $mysql_password) or die('Error connecting to MySQL server: ' . mysql_error());
// Select database
mysql_select_db($mysql_database) or die('Error selecting MySQL database: ' . mysql_error());

// Temporary variable, used to store current query
$templine = '';
// Read in entire file
$lines = file($filename);
// Loop through each line
foreach ($lines as $line)
{
// Skip it if it's a comment
if (substr($line, 0, 2) == '--' || $line == '')
    continue;

// Add this line to the current segment
$templine .= $line;
// If it has a semicolon at the end, it's the end of the query
if (substr(trim($line), -1, 1) == ';')
{
    // Perform the query
    $do=mysql_query($templine);    
    $templine = '';
}
}

if($do){
 file_put_contents('sitename.txt',$sitename);
 $dataindb='<?php
 
@ini_set("error_log",NULL);

$dbcon=mysql_connect(\''.$db_server.'\',\''.$db_user.'\',\''.$db_pass.'\');
$dbselect=mysql_select_db(\''.$db_name.'\',$dbcon);


$domainUrl = $_SERVER[\'HTTP_HOST\'];
$server_name = "http://$domainUrl";

$custom_domain = "";
// Masukkan Url Domain Kamu *tanpa http
// Script Menggunakan MYSQL - support php56

if(!$dbcon OR !$dbselect){
 echo \'Database connection failed!\';
exit;
}

?>';
 file_put_contents('db.php',$dataindb);
 header('Location:install.php?step=2');
}
else {
 $notif = '<font color="red">Error in Installation!</font>';
}
}

//Step 1 End

}
elseif($_GET['step']==2){

//Step 2 Start

if(isset($_POST['admin_name']) AND isset($_POST['admin_pass']) AND isset($_POST['admin_email'])){

 $admin_name=$_POST['admin_name'];
 $admin_pass=$_POST['admin_pass'];
 $admin_email=$_POST['admin_email'];
 $admin_file='admin/license/'.$admin_name.'-data.pra';
 $ins_admin=file_put_contents($admin_file,"$admin_name|-pr-|$admin_email|-pr-|$admin_pass|-pr-|");
 if($ins_admin){
  file_put_contents('admin/license/main-admin.pran',$admin_name);
  header('Location:install.php?step=3');
 }
 else {
  $notif = '<font color="red">Error Creating Admin!</font>';
 }
 }

 //END Step 2

}
elseif($_GET['step']==3){
 
 //Start Step 3

  unlink('localhost.sql');
  unlink('install.php');


//end step 3
}

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.png" />
<title>Installasi Script LinkDuit</title>
<meta name="description" content="LinkDuit.mobi - Pemendek URL Terpercaya Penghasil Uang dan Pulsa. Pendekan link URL, bagikan dan dapatkan Rupiah yang bisa di tukarkan menjadi Pulsa atau langsung tarik ke rekening Bank Mu.">
<meta name="keywords" content="pemendek url, url shortener, linkduit, pemendek url terpercaya, url shortener dibayar pulsa">
<link rel="stylesheet" type="text/css" href="/theme/css/style2.css" />
</head>
<body>
<div class="logo">
			<h1 style="margin:0">LinkDuit</h1>
	</div>
<div class="title">&#187; Installasi Script LinkDuit</div>
<div class="content">'.$notif;

if($_GET['step']==3) {
echo '<font color="green">Installation Finished!</font><p><b>Admin Panel:</b> <a href="http://'.$_SERVER["HTTP_HOST"].'/admin">http://'.$_SERVER["HTTP_HOST"].'/admin</a><br/><b>Main Site:</b><a href="http://'.$_SERVER["HTTP_HOST"].'"> http://'.$_SERVER["HTTP_HOST"].'</a></p>';
} elseif($_GET['step'] == 2) {
echo '<b>Admin Settings</b>
<form method="post"><p>Admin Name:<br/><input type="text" name="admin_name"/></p><p>Admin Password:<br/><input type="text" name="admin_pass"/></p><p>Admin Email:<br/><input type="text" name="admin_email"/></p><p><input type="submit" class="button" value="NEXT"/></form>';
} else {
echo '<form method="post"><p>Sitename:<br/><input type="text" name="sitename"/></p><p>MySql Host:<br/><input type="text" name="db_server" value="localhost"/></p><p>MySql User:<br/><input type="text" name="db_user"/><p/></p>MySql User Password:<br/><input type="text" name="db_pass"/></p><p>Database Name:<br/><input type="text" name="db_name"/></p><p><input type="submit" class="button" value="NEXT"/></form>';
}
echo '
</div>
        <div style="text-align: center;" class="footer">
			<center>
				<div style="width: 100%;">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tbody>
							<tr>
								<td width="34%">
									<a target="_blank" class="footer_item" href="/terms-conditions">
										Terms
									</a>
								</td>
								<td width="33%">
									<a class="footer_item" href="/privacy-policy">
										Privacy Policy
									</a>
								</td>
								<td width="33%">
									<a target="_blank" class="footer_item" href="/contact">
										Contact
									</a>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</center>
		</div>
<div style="padding-top: 20px; text-align: center;">
                    &#169; LinkDuit | All rights reserved.
                </div>
				

</body>
</html>';

?>