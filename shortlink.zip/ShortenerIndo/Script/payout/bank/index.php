<?php


include '../../db.php';

include '../../functions.php';


headtag("$SiteName - Paypal Payout");


if($userlog==1){


$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Bank Transfer
	</div>
	<div class="content">';

if(dump_udata("pubalance")<50000){

echo '<font color="red">Saldo anda tidak mencukupi. saat ini anda memiliki <b>Rp '.dump_udata("pubalance").',-</b>! Minimal pembayaran Bank adalah <b>Rp 50000,-</b>. Silahkan coba lagi nanti!</font><br/>';

}

else
{

$uid=dump_udata("id");

if(isset($_POST["amount"]) AND isset($_POST["method"]) AND isset($_POST["via"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method=formpost("method");
$via=formpost("via");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){

$errors[]='<font color="red">Error:</font> Amount harus berupa angka saja", Contoh: <font color="green">50000</font><br/>';
 }


if(strlen($amount)<1){

$errors[]='<font color="red">Error:</font> Amount cannot be empty!<br/>';
 }

if(strlen($method)<1){

$errors[]='<font color="red">Error:</font> Payment method cannot be empty!<br/>';
 }

if(strlen($name)<1){
  $errors[]='<font color="red">Error:</font> Your Name cannot be empty!<br/>';
 }

if(strlen($via)<1){
  $errors[]='<font color="red">Error:</font> Nomor Rekening cannot be empty!<br/>';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='<font color="red">Error:</font> Amount is bigger than account balance!<br/>';
}

if($amount<50000){
  $errors[]='<font color="red">Error:</font> Minimal payout adalah <b>50000</b> !<br/>';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysql_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','$method','$via','Pending','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><center><font color="green">Invoice successfully Created and will be paid soon.</font> <font color="green">Please check</font> <a href="/user/invoices">Payment Messege</a> <font color="green">for see your payment status!</font></center><br/>';
  }
  else {
   echo '<br/><center><font color="red">Error creating invoice!</font></center><br/>';
}

}
else {

dump_error($errors);


}

}

echo '
<div class="registration-login">
<form method="post">
<p>
Payment method:<br/><select name="method"><option value="BRI">BRI</option>
<option value="BNI">BNI</option><option value="MANDIRI">MANDIRI</option><option value="BCA">BCA</option></select></p>
<p>
Amount: (Min: <b>50000</b> - Max: <b>'.dump_udata("pubalance").')</b><br/>
<input type="text" name="amount" placeholder="50000"/></p>

<p>Atas Nama:<br/><input type="text" name="name"/></p>
<p>Nomor Rekening:<br/><input type="text" name="via"/></p>
<p><input class="button" type="submit" value="Submit"/></p>
</form>
</div>';


}

}

else {


header('Location:/');

}


echo '</div>';

include '../../foot.php';


?>