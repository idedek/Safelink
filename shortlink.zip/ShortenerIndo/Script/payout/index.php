<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - Request Payout");

if($userlog==1){
$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Request Pembayaran
	</div>
	<div style="padding-top: 10px; padding-bottom: 40px;">
	
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/pay2.png" /> <a href="/payout/pulsa">Pulsa All Operator</a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/gopay.png" width="16px" /> <a href="/payout/gopay">GO-PAY </a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/ovo.png" /> <a href="/payout/ovo">OVO </a> (Proses Lambat)
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/pln.png" /> <a href="/payout/pln">Pulsa/Token Listrik </a>
		</div>
		<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/ppku.png" /> <a href="/payout/paypal">Paypal </a>
		</div>
				<div class="cabinet_item">
			<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/pay3.png" /> <a href="/payout/bank">Bank Transfer</a>
		</div>
</div>';

}
else {

header('Location:/');
}
echo '</div>';
include '../foot.php';

?>