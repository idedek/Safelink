<?php

include '../../db.php';
include '../../functions.php';

headtag("$SiteName - Pulsa/Token Listrik");

if($userlog==1){

$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Pulsa/Token Listrik
	</div>
	<div class="content">';
if(dump_udata("pubalance")<20999){
 echo '<font color="red">Saldo Tidak Cukup! Saldo Anda adalah <b>Rp '.dump_udata("pubalance").'</b>! Minimal Payout Menggunakan Token listrik adalah <b>Rp 21.000,-</b> !</font>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["nohp"]) AND isset($_POST["via"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method="Token Listrik";
$nohp=formpost("nohp");
$via=formpost("via");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='<font color="red">Error:</font> Amount must be a numeric value without "<font color="red">$</font>", Example: <font color="green">10</font><br/>';
 }


if(strlen($amount)<1){
  $errors[]='<font color="red">Error:</font> Amount cannot be empty!<br/>';
 }

if(strlen($method)<1){
  $errors[]='<font color="red">Error:</font> Payment method cannot be empty!<br/>';
 }

if(strlen($name)<1){
  $errors[]='<font color="red"><b>Error:</b></font> Nama Anda Tidak Boleh Kosong!<br/>';
 }


if(strlen($via)<1){
  $errors[]='<font color="red"><b>Error:</b></font>NO Meter atau ID Pelanggan Tidak Boleh Kosong!<br/>';
 }

if(strlen($nohp)<1){
  $errors[]='<font color="red">Error:</font>NO HP Tidak Boleh Kosong!<br/>';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='<font color="red"><b>Error:</b></font> Maaf, Saldo Anda Tidak Mencukupi!<br/>';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysql_query("INSERT INTO invoice (userid,amount,method,via,status,time,nohp,name) VALUES ('$uid','$amount','$method','$via','Pending','$date','$nohp','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><center><font color="green">Permintaan Payout Anda Telah Kami Terima dan Akan diproses setiap hari <b>Sabtu</b> Sesuai Antrian. Silahkan Cek Status Pembayaran pada Halaman </font> <a href="/user/invoices">Payment Messege</a>!</font></center><br/>';
  }
  else {
   echo '<br/><center><font color="red">Error creating invoice!</font></center><br/>';
}

}
else {

dump_error($errors);

}
}
echo '
<b>Info Harga Payout Token Listrik:</b>
<br />
<font color="black">
1. Pulsa 20 Ribu = <b>Rp 21.000,-</b><br/>
2. Pulsa 50 Ribu = <b>Rp 52.000,-</b><br/>
3. Pulsa 100 Ribu = <b>Rp 102.000,-</b></font>
<p>
<form method="post">
<p>NO Meter atau ID Pelanggan<br/><input type="text" name="via"/></p>
<p>Nominal Saldo:<br/><select name="amount">
<option value="21000">20 Ribu</option>
<option value="52000">50 Ribu</option>
<option value="102000">100 Ribu</option>
</select></p>
<p>NO HP: (Contoh: 08123456789)<br/><input type="text" name="nohp"/></p>
<p>Nama Anda:<br/><input type="text" name="name"/></p>
<p><input class="button" type="submit" value="Submit"/></p>
</form>
</div>';

}
}
else {

header('Location:/');
}

echo '</div>';
include '../../foot.php';

?>