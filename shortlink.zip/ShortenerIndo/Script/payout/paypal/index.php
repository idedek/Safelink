<?php

include '../../db.php';
include '../../functions.php';

headtag("$SiteName - Paypal");

if($userlog==1){

$ratePerDollar = 15500;

$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Paypal
	</div>
	<div class="content">'; if(dump_udata("pubalance")<74999){

echo '<div class="news"><font color="red">Saldo anda tidak mencukupi. saat ini anda memiliki <b>Rp '.dump_udata("pubalance").',-</b>! Minimal pembayaran via paypal adalah <b>$5 = Rp 75.000,-</b>. Silahkan coba lagi nanti!</font></div>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["method"]) AND isset($_POST["via"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method=formpost("method");
$via=formpost("via");
$name=formpost("name");
$amount = $amount*$ratePerDollar;
$errors=array();

if(!is_numeric($amount)){
  $errors[]='<font color="red">Error:</font> Amount must be a numeric value without "<font color="red">$</font>", Example: <font color="green">10</font><br/>';
 }


if(strlen($amount)<1){
  $errors[]='<font color="red">Error:</font> Amount cannot be empty!<br/>';
 }

if(strlen($method)<1){
  $errors[]='<font color="red">Error:</font> Payment method cannot be empty!<br/>';
 }

if(strlen($name)<1){
  $errors[]='<font color="red"><b>Error:</b></font> Nama Anda Tidak Boleh Kosong!<br/>';
 }

if(strlen($via)<1){
  $errors[]='<font color="red"><b>Error:</b></font> Email cannot be empty!<br/>';
 }

if($amount<74999){
  $errors[]='<font color="red">Error:</font> Minimal payout adalah <b>75000</b>, total conversi adalah $'.formpost("amount").' = Rp '.$amount.' <br/>';
}

if($amount>dump_udata("pubalance")){
  $errors[]='<font color="red"><b>Error:</b></font> Maaf, Saldo Anda Tidak Mencukupi!<br/>';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysql_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','$method','$via','Pending','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><center><font color="green">Permintaan Payout Anda Telah Kami Terima dan Akan diproses setiap hari <b>Sabtu</b> Sesuai Antrian. Silahkan Cek Status Pembayaran pada Halaman </font> <a href="/user/invoices">Payment Messege</a>!</font></center><br/>';
  }
  else {
   echo '<br/><center><font color="red">Error creating invoice!</font></center><br/>';
}

}
else {

dump_error($errors);

}
}
echo '
<form method="post">
<p>
Payment method:<br/><select class="w3-input" name="method">
<option value="Paypal">Paypal</option></select></p>
<p>
Amount: (Min: <b>$5</b>)</b><br/>
<input class="w3-input" type="text" name="amount" placeholder=" Contoh $5.5 isi dengan 5.5"/></p>

<p>Atas Nama:<br/><input class="w3-input" type="text" name="name" placeholder=" Masukkan nama akun paypal" /></p>
<p>Alamat Email Paypal:<br/><input class="w3-input" type="text" name="via" placeholder=" Masukkan alamat email paypal" /></p>
<p><input class="w3-button w3-teal" type="submit" value="Submit"/></p>
</form>
</div>';

}
}
else {

header('Location:/');
}

echo '</div>';
include '../../foot.php';

?>