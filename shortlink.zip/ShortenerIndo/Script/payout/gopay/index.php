<?php

include '../../db.php';
include '../../functions.php';

headtag("$SiteName - GO-PAY");

if($userlog==1){

$uid=dump_udata("id");
echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; GO-PAY
	</div>
	<div class="content">';
if(dump_udata("pubalance")<12000){
 echo '<font color="red">Saldo Tidak Cukup! Saldo Anda adalah <b>Rp '.dump_udata("pubalance").'</b>! Minimal Payout Menggunakan GO-PAY adalah <b>Rp 12.000,-</b> !</font><br/>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["method"]) AND isset($_POST["via"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method=formpost("method");
$via=formpost("via");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='<font color="red">Error:</font> Amount must be a numeric value without "<font color="red">$</font>", Example: <font color="green">10</font><br/>';
 }


if(strlen($amount)<1){
  $errors[]='<font color="red">Error:</font> Amount cannot be empty!<br/>';
 }

if(strlen($method)<1){
  $errors[]='<font color="red">Error:</font> Payment method cannot be empty!<br/>';
 }

if(strlen($name)<1){
  $errors[]='<font color="red"><b>Error:</b></font> Nama Anda Tidak Boleh Kosong!<br/>';
 }

if(strlen($via)<1){
  $errors[]='<font color="red"><b>Error:</b></font> NO HP Tidak Boleh Kosong!<br/>';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='<font color="red"><b>Error:</b></font> Maaf, Saldo Anda Tidak Mencukupi!<br/>';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysql_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','$method','$via','Pending','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<br/><center><font color="green">Permintaan Payout Anda Telah Kami Terima dan Akan diproses setiap hari <b>Sabtu</b> Sesuai Antrian. Silahkan Cek Status Pembayaran pada Halaman </font> <a href="/user/invoices">Payment Messege</a>!</font></center><br/>';
  }
  else {
   echo '<br/><center><font color="red">Error creating invoice!</font></center><br/>';
}

}
else {

dump_error($errors);

}
}
echo '
<b>Info Harga Payout GO-PAY:</b><br />
<font color="black">
1. Pulsa 10 Ribu = <b>Rp 12.000,-</b><br/>
2. Pulsa 25 Ribu = <b>Rp 26.000,-</b><br/>
3. Pulsa 50 Ribu = <b>Rp 53.000,-</b><br/>
4. Pulsa 100 Ribu = <b>Rp 102.000,-</b></font><br/>
<div class="alinea"></div>
<div class="registration-login">
<form method="post">
<p>Payment:<br/><select name="method">
<option value="GO-PAY">GO-PAY</option>
</select></p>
<p>Nominal Pulsa:<br/><select name="amount">
<option value="12000">10 Ribu</option>
<option value="26000">25 Ribu</option>
<option value="53000">50 Ribu</option>
<option value="102000">100 Ribu</option>
</select></p>
<p>NO HP: (Contoh: 08123456789)<br/><input type="text" name="via"/></p>
<p>Nama Anda:<br/><input type="text" name="name"/></p>
<p><input class="button" type="submit" value="Submit"/></p>
</form>
</div>';

}
}
else {

header('Location:/');
}

echo '</div>';
include '../../foot.php';

?>