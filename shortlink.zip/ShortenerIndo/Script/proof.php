<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName Bukti Pembayaran");

   echo '
	<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="50%">
												<a class="header_item" href="/user/login">
													<div style="background-image: url(/style/images/enter.png); margin-right: 2px;" class="icon"></div>
													Masuk
												</a>
											</td>
											<td width="50%">
												<a class="header_item" href="/user/registration">
													<div style="background-image: url(/style/images/register-account.png); margin-right: 2px;" class="icon"></div>
													Pendaftaran
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">&#187; Bukti Pembayaran</div>
		<div class="content">';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=(10);
$getData=mysql_query("SELECT * FROM invoice WHERE status LIKE '%%' ORDER BY id DESC LIMIT $start, $end");

if(mysql_num_rows($getData)>0){

while($fetchData=mysql_fetch_array($getData)){
echo '
<p><img style="vertical-align: middle; margin-right: 10px;" src="/style/images/tag.png" />ID Pembayaran: <b>PO#'.$fetchData['id'].'</b><br/>
<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/cashout.png" />Jumlah: <font color="green"><b>Rp '.number_format($fetchData['amount'],"0",",",".").'</b></font><br/>
<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/to.png" />Nama: <b><font color="orange">'.ucwords($fetchData['name']).'</font></b><br/>
<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/method.png" />Melalui: <font color="blue"><b>'.$fetchData['method'].'</b></font><br/>
<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/to.png" />Dikirim ke: <b><font color="blue">'.substr($fetchData['via'],0,9).'</font><font color="red">xxx</font></b><br/>
<img style="vertical-align: middle; margin-right: 10px;" src="/style/images/list.png" />Status: <b>'.$fetchData['status'].'</b> ('.$fetchData['time'].')</p>
<p><hr /></p>';
}
echo '
<center><a href="/user/invoices?page='.($page-1).'">&laquo; Sebelumnya</a> - <a href="/user/invoices?page='.($page+1).'">Selanjutnya &raquo;</a></center>';
} else {
echo '
<center><font color="red">Belum ada bukti pembayaran !</font></center>';
}

echo '</div>';

include 'foot.php';

?>