<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Terms and Conditions");

$imp=mysql_query("SELECT * FROM imp");
$imps=0;

while($show=mysql_fetch_array($imp)){
$imps=($imps+$show['imp']);
}
$invoice=mysql_query("SELECT * FROM invoice");
$invoices=0;

while($show=mysql_fetch_array($invoice)){
$invoices=($imps+$show['amount']);
}
$site=mysql_num_rows(mysql_query("SELECT * FROM sites"));


echo '
<div class="title">Contact Us / Hubungi Kami</div>
	       <div style="padding: 10px;">
		   <p>For questions and assistance please contact the contact below / Untuk pertanyaan dan bantuan silahkan hubungi kontak dibawah ini: </p>
		<p><b>&#8226; <font color="green">Email</font> : support@'.$_SERVER['HTTP_HOST'].'</b></p></div>';

include 'foot.php';

?>
