<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Dashboard");


if($userlog==1){
$uid=dump_udata("id");

if(dump_udata("status")=='INACTIVE'){
echo '
<div class="content">
<center><font color="red"><b>Account Inactive !</b></font><br/><br/>Your account is inactive. Please check <u>INBOX</u> or <u>SPAM</u> folder on your email account, and click on the activation link sent to your email to activate your account!</center>';
echo '</div>';
exit;
}



echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Penghasilan
	</div>
	<div class="content">
		<table width="100%" cellpadding="0" cellspacing="0">
			<tbody>
				<tr>
					<td width="100%" style="text-align: left;">
						<img style="vertical-align: middle; margin-right: 5px;" src="/style/images/Purse-32.png" width="24px" height="24px" /> Penghasilan Saya: <b>Rp '.number_format(dump_udata('pubalance')).',-</b>
					</td>
				</tr>
			</tbody>
		</table>
		<p><a href="/payout/">&#187; Request Pembayaran</a></p>
		   <p><a href="/user/stats">&#187; Lihat Statistik</a></p>
</div>';



//enf
}
else {
header('Location:/');
}

include 'foot.php';

?>

