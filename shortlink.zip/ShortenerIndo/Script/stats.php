<?php

include 'db.php';
include 'functions.php';

headtag("$SiteName - Earning Reports");


if($userlog==1){
$uid=dump_udata("id");

$d=date("d");

echo '
<div class="header">
			<center>
				<div style="width: 100%;">
													<table width="100%" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td width="34%">
												<a class="header_item" href="/user/dashboard">
													<div style="background-image: url(/style/images/admin_company.png); margin-right: 2px;" class="icon"></div>
													Dashboard
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/money">
													<div style="background-image: url(/style/images/dollar-icon.png); margin-right: 2px;" class="icon"></div>
													Penghasilan
												</a>
											</td>
											<td width="33%">
												<a class="header_item" href="/user/logout">
													<div style="background-image: url(/style/images/logout-icon.png); margin-right: 2px;" class="icon"></div>
													Logout
												</a>
											</td>
										</tr>
									</tbody>
								</table>
											</div>
			</center>
		</div>
		<div class="title">
		&#187; Statistik hari ini
	</div>
	<div class="content">

<h2 id="start" class="heading-lined android-font-19">
            <span class="text-overlay">Earning Reports</span>
            <span class="heading-line bg-blue"></span>
        </h2>
<div><center>
<table class="table" width="100%" cellpadding="0" cellspacing="0">
<thead>
<tr>
<th style="text-align: center; padding: 20px;" colspan="0%">Tanggal</th>
<th style="text-align: center; padding: 20px;" colspan="0%">Visit Valid</th>
<th style="text-align: center; padding: 20px;" colspan="0%">Penghasilan (Rp)</th>
</tr>
</thead>
<tbody>';

for($i=$d;$i>0;$i--){

if(strlen($i)==1){
 $i="0$i";
}

$datee=date("".$i."-m-Y");

$imps=mysql_fetch_array(mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$datee'"));
$imp=$imps["imp"];
if(empty($imp)){
$imp=0;
}
$rates=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE id='1'"));
$rate=$rates["rate"];
$clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE userid='$uid' AND time='$datee' AND status='VALID'"));
$earn=($clicks*$rate);

echo '<tr>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$datee.'</td>
<td style="text-align: center; padding: 20px;" colspan="0%">'.$clicks.'</td>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>'.$earn.'</b></td>
</tr>';

}
$timps=mysql_query("SELECT * FROM imp WHERE uid='$uid'");
$timp=0;

while($tshow=mysql_fetch_array($timps)){
$timp=($timp+$tshow['imp']);
}
$tclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE userid='$uid' AND time='$datee' AND status='VALID'"));
$tearn=($tclicks*0.0005);

echo '<tr>
<td style="text-align: center; padding: 20px;" colspan="0%"><b>Total</b></td>
<td style="text-align: center; padding: 20px;" colspan="0%"><b id="num">'.$tclicks.'</b></td>
<td style="text-align: center; padding: 20px;" colspan="0%"><b id="num">'.$tearn.'</b></td>
</tr>';

echo '
</tbody>
</table>
</center>
</div>
</div>';		

include 'foot.php';

}
else {
header('Location:/');
}
?>
