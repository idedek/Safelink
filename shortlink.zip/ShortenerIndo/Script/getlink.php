<?php

include 'db.php';
include 'functions.php';

$userid=$_POST['userid'];
$short=$_POST['short'];
$uagent=$_POST['uagent'];
$ipaddress=$_POST['ipaddress'];
$referer=$_POST['referer'];
$urltidak=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));
$tidak=$urltidak["url_link"];
$urliya=mysql_fetch_array(mysql_query("SELECT * FROM urls WHERE url_short='$short'"));
$iya=$urliya["url_link"];

$errors=array();

if(empty($ipaddress)){
$errors[]='a';
}
if(empty($uagent)){
$errors[]='a';
}
if(empty($referer)){
$errors[]='a';
}
$date=date("d-m-Y");

$chIp=mysql_query("SELECT * FROM clicks WHERE ip='$ipaddress' AND time='$date'");

if(mysql_num_rows($chIp)>0){
 $errors[]='a';
}

if(empty($errors)){
 
 $rates=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE id='1'"));
 $ucpc=$rates["rate"];
 $User=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$userid'"));
 $aUser=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$adowner'"));
 $userbal=$User["pubalance"];

 $newU=($userbal+$ucpc);

 $doIt1=mysql_query("UPDATE userdata SET pubalance='$newU' WHERE id='$userid'");
 $doIt2=mysql_query("UPDATE affiliates SET balance='$newR' WHERE rid='$userid'");
 $doIt3=mysql_query("INSERT INTO clicks (ip,ua,host,userid,urlid,time,status) VALUES ('$ipaddress','$uagent','$referer','$userid','$short','$date','VALID')");

 if($doIt1 AND $doIt2 AND $doIt3){
   header("Location:$iya");
 }
 }
 else {

   $doIt4=mysql_query("INSERT INTO clicks (ip,ua,host,userid,urlid,time,status) VALUES ('$ipaddress','$uagent','$referer','$userid','$short','$date','INVALID')");
   if($doIt4){
    header("Location:$tidak");

  }
 }

?>